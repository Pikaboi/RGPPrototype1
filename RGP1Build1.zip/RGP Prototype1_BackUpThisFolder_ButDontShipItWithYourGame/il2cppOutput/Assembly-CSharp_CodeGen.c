﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif



#include "codegen/il2cpp-codegen-metadata.h"





IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END




// 0x00000001 System.Void MainMenu::Start()
extern void MainMenu_Start_mDF8837F303DD240CE4438A6ABC3D07F7D9B3620E ();
// 0x00000002 System.Void MainMenu::Update()
extern void MainMenu_Update_mFAD507C36372E10DEC5939AB521016F0A36D4BBF ();
// 0x00000003 System.Void MainMenu::nextLevel()
extern void MainMenu_nextLevel_m126AD0F612D27E950C38BCFC775C9817954F1824 ();
// 0x00000004 System.Void MainMenu::quitGame()
extern void MainMenu_quitGame_m4AAE7E4C2F1EE3FA0F7A88130F5D661211FA158A ();
// 0x00000005 System.Void MainMenu::.ctor()
extern void MainMenu__ctor_m63F945D965550BD614DCD2AE7F7489D4F28C5B30 ();
// 0x00000006 System.Void NumPadInput::Start()
extern void NumPadInput_Start_m770DD05782E1443128394BBD97A09D624B815A11 ();
// 0x00000007 System.Void NumPadInput::Update()
extern void NumPadInput_Update_m3C11999B443BD0A297B242A735CB3091A5E84172 ();
// 0x00000008 System.Void NumPadInput::add1()
extern void NumPadInput_add1_m1769E3D44F6915ABD03199BFCB39A7B1E633C8D9 ();
// 0x00000009 System.Void NumPadInput::add2()
extern void NumPadInput_add2_m2673080B55DA2826727DA10617F2E2081775B52F ();
// 0x0000000A System.Void NumPadInput::add3()
extern void NumPadInput_add3_mBC7BE1EE797934E36BA700CD6A48E96526251F54 ();
// 0x0000000B System.Void NumPadInput::add4()
extern void NumPadInput_add4_mAD5B3E01F1A111604D55B2E5468B45B07BE4083E ();
// 0x0000000C System.Void NumPadInput::add5()
extern void NumPadInput_add5_m2D9844D15B2CF0A5233E98B06AE8D23DC15C666B ();
// 0x0000000D System.Void NumPadInput::add6()
extern void NumPadInput_add6_mCB6A7E675D66025087DEC6C6B4B967777EB5E4F1 ();
// 0x0000000E System.Void NumPadInput::add7()
extern void NumPadInput_add7_m97AD41C6B36D0CB2E83E769A07F36E6EB3C70CE1 ();
// 0x0000000F System.Void NumPadInput::add8()
extern void NumPadInput_add8_m40D553A7969807286A55B8417938A84281F0A43B ();
// 0x00000010 System.Void NumPadInput::add9()
extern void NumPadInput_add9_mB6C36F4947F65F2851C62E7005CF088AABF7145F ();
// 0x00000011 System.Void NumPadInput::add0()
extern void NumPadInput_add0_mC99A6277C30A2C00AE776E5F9FDF03DD4939798E ();
// 0x00000012 System.Void NumPadInput::Exit()
extern void NumPadInput_Exit_m9E5D56CB6B21D23DECEE02F376C7BF93FB3698A7 ();
// 0x00000013 System.Void NumPadInput::Enter()
extern void NumPadInput_Enter_m8F2DC1AD7D8F158B65DDFF4387019FD9694EB3CC ();
// 0x00000014 System.Void NumPadInput::.ctor()
extern void NumPadInput__ctor_m81E70D543EFC90A6527FB0E1251E30B8AC44B1B9 ();
// 0x00000015 System.Void followPlayer::Start()
extern void followPlayer_Start_m57B009531B073D04C015F6EE7B42F1AC5290E2EB ();
// 0x00000016 System.Void followPlayer::Update()
extern void followPlayer_Update_mC554D294B28EC73DFE8FD40788CB969EBEAD6E3A ();
// 0x00000017 System.Void followPlayer::.ctor()
extern void followPlayer__ctor_m20D327E97E8A60D7BC77E2E26F2887E8ABA47E0A ();
// 0x00000018 System.Void mouseLook::Start()
extern void mouseLook_Start_mCD34D1DE77D44AD36B5828211814A8DC287ABFCC ();
// 0x00000019 System.Void mouseLook::Update()
extern void mouseLook_Update_mB74CE81BBB08E50015C3A343FAD0CC74EA96B66D ();
// 0x0000001A System.Void mouseLook::.ctor()
extern void mouseLook__ctor_mAA071B4976040EB8F2C410970F3762E539A6F118 ();
// 0x0000001B System.Void playerMovement::Start()
extern void playerMovement_Start_m2CCFD2E55DD1946EAA2AE537FECC34CB411A0367 ();
// 0x0000001C System.Void playerMovement::Update()
extern void playerMovement_Update_m60C2DE2B3C0A9CFD6EA6CBBDE99CA74CBAB7C733 ();
// 0x0000001D System.Void playerMovement::enableHintInteract(InteractibleHint)
extern void playerMovement_enableHintInteract_mE62B2177C62A02D3A18C0FEEA548CED9A1D0A040 ();
// 0x0000001E System.Void playerMovement::enableItemInteract(InteractibleItem)
extern void playerMovement_enableItemInteract_m025019E9433CDB97C189CABB662665A74B0494F2 ();
// 0x0000001F System.Void playerMovement::enableNumpadInteract(InteractNumpad)
extern void playerMovement_enableNumpadInteract_mD8646B0698146C32453CEA9B45277C452F5C1146 ();
// 0x00000020 System.Void playerMovement::disableHintInteract()
extern void playerMovement_disableHintInteract_m29BEF1431784EA44A9D90F54D0420233D5D68468 ();
// 0x00000021 System.Void playerMovement::disableItemInteract()
extern void playerMovement_disableItemInteract_mD2FF484C3367EAD46D515D8AD79E5B2402D263B5 ();
// 0x00000022 System.Void playerMovement::disableNumpadInteract()
extern void playerMovement_disableNumpadInteract_m5A3057C6DF4C84FD9CDB99D5FDCA76C4F605D188 ();
// 0x00000023 System.Void playerMovement::.ctor()
extern void playerMovement__ctor_mE5A7BD43C0E23AC70BF117434F0AC89D0DF3E108 ();
// 0x00000024 System.Void DoorOpen::Start()
extern void DoorOpen_Start_m1F7E9B7B98007752ECA86CE3F831CCE60B9A94D8 ();
// 0x00000025 System.Void DoorOpen::Update()
extern void DoorOpen_Update_m4F68D3A52A3D0D12B0811709F6BCD8DDD78C7C1F ();
// 0x00000026 System.Void DoorOpen::OpenDoor()
extern void DoorOpen_OpenDoor_m44EC3B72936DD5AD22E73C3506A0516C3761B582 ();
// 0x00000027 System.Void DoorOpen::.ctor()
extern void DoorOpen__ctor_m0B1CE4F8A078F82062E622AA921F22F675015CB5 ();
// 0x00000028 System.Void InteractNumpad::Start()
extern void InteractNumpad_Start_m29864E7F28C2523419E1EB6CE0847D75F231C3B5 ();
// 0x00000029 System.Void InteractNumpad::Update()
extern void InteractNumpad_Update_mEF918536C388526C078AAD9FC94808CE8EAC2AD8 ();
// 0x0000002A System.Void InteractNumpad::OnTriggerEnter(UnityEngine.Collider)
extern void InteractNumpad_OnTriggerEnter_m9AE5233D580CD72B54A34CB8B9C790AD6B3B545D ();
// 0x0000002B System.Void InteractNumpad::Deactivate()
extern void InteractNumpad_Deactivate_m23C58094158C7277A20E19A34DDFAA8F902AFE45 ();
// 0x0000002C System.Void InteractNumpad::Return()
extern void InteractNumpad_Return_mFF049E7E8D404323F6ED214A7120E284DF0BA6F6 ();
// 0x0000002D System.Void InteractNumpad::turnOn()
extern void InteractNumpad_turnOn_m06D70182BEBA7C25983B8DF0C02AAA5BBF758702 ();
// 0x0000002E System.Void InteractNumpad::.ctor()
extern void InteractNumpad__ctor_m45EC8C9E1240CE478C857EB2823D5BB9C6053129 ();
// 0x0000002F System.Void InteractibleHint::Start()
extern void InteractibleHint_Start_m6AA6214DC4A979A467D3ACD98A044ED2BA84C1BD ();
// 0x00000030 System.Void InteractibleHint::Update()
extern void InteractibleHint_Update_m321C2762F96D94575F4EEC5D84EA25A1F31B0916 ();
// 0x00000031 System.Void InteractibleHint::OnTriggerEnter(UnityEngine.Collider)
extern void InteractibleHint_OnTriggerEnter_mF6E482BD49AFE1B43DA8704FEE7292DA332F4ACD ();
// 0x00000032 System.Void InteractibleHint::OnTriggerExit(UnityEngine.Collider)
extern void InteractibleHint_OnTriggerExit_mBFEFED90CF5142C6460BA7B1071CC750326A6BA1 ();
// 0x00000033 System.Void InteractibleHint::interactText()
extern void InteractibleHint_interactText_m959B141436B50FAA92CDBE31BA2E74F622670F67 ();
// 0x00000034 System.Void InteractibleHint::.ctor()
extern void InteractibleHint__ctor_mCDA92B4294141D3C36FB072728532A24D25DD55D ();
// 0x00000035 System.Void InteractibleItem::Start()
extern void InteractibleItem_Start_mA5F84C52952863EF93D3B7C6A1B0D0C85F9A6024 ();
// 0x00000036 System.Void InteractibleItem::Update()
extern void InteractibleItem_Update_m92DBB646296893B9AF37376F70A95D12535FD1BF ();
// 0x00000037 System.Void InteractibleItem::OnTriggerEnter(UnityEngine.Collider)
extern void InteractibleItem_OnTriggerEnter_m414553CC5037578D349CC65292832E7524F2CF75 ();
// 0x00000038 System.Void InteractibleItem::OnTriggerExit(UnityEngine.Collider)
extern void InteractibleItem_OnTriggerExit_m1EF38906A3EE6719D35B8AEE1CDCD1802FEB3064 ();
// 0x00000039 System.Void InteractibleItem::BecomeActive()
extern void InteractibleItem_BecomeActive_mA131543EC94CD29FDE63C23BCEF77CEB4B4F924F ();
// 0x0000003A System.Void InteractibleItem::interactCollect()
extern void InteractibleItem_interactCollect_m83C15082A5E82E2EF808CED5960112677887B30D ();
// 0x0000003B System.Void InteractibleItem::.ctor()
extern void InteractibleItem__ctor_m982771AA06BF0083EE8222D2ED8DF56E2F567F15 ();
// 0x0000003C System.Void PanelControl::Start()
extern void PanelControl_Start_mB2A2A55E5527B44BAA46E986EC58723B8050EA00 ();
// 0x0000003D System.Void PanelControl::Update()
extern void PanelControl_Update_mA715533B8AC6090CD005F8F168E0EFD196124409 ();
// 0x0000003E System.Void PanelControl::startFade()
extern void PanelControl_startFade_mC7A822669B09A1D028FA7CBDD96DA64BD6685D8A ();
// 0x0000003F System.Void PanelControl::startSolidify(System.Int32)
extern void PanelControl_startSolidify_m802E606D154466FAFA5A17539489C0A5A0668AD2 ();
// 0x00000040 System.Void PanelControl::startSolidify()
extern void PanelControl_startSolidify_m067BFA5830EB5ABC9BB1578B8DAE00B6F58813E9 ();
// 0x00000041 System.Void PanelControl::fading()
extern void PanelControl_fading_m080C750E20CB7B2CA4C4CD0602C3D89057D0C4F7 ();
// 0x00000042 System.Void PanelControl::solidifying()
extern void PanelControl_solidifying_mB01CBC88B531C63C44FAAE7E2ADB337243536845 ();
// 0x00000043 System.Void PanelControl::.ctor()
extern void PanelControl__ctor_m92F226F124CE2DF289B41070F7ADB29D6DD82B4B ();
// 0x00000044 System.Void SceneChangeFixed::OnTriggerEnter(UnityEngine.Collider)
extern void SceneChangeFixed_OnTriggerEnter_mCF1D098F9D5559F4961C4CB72755851AE1C49AC2 ();
// 0x00000045 System.Void SceneChangeFixed::Start()
extern void SceneChangeFixed_Start_mF323354487A870B8D919E85D311E159C8E6858EB ();
// 0x00000046 System.Void SceneChangeFixed::Update()
extern void SceneChangeFixed_Update_m8938E1961155D660EA64EA5EC762483414BA863E ();
// 0x00000047 System.Void SceneChangeFixed::.ctor()
extern void SceneChangeFixed__ctor_mF203BF816CA622A7662A7008243992318D2F327E ();
// 0x00000048 System.Void SceneChanger::Start()
extern void SceneChanger_Start_m6B81BE1B9D274D067D3554052D413F8495A6E5E7 ();
// 0x00000049 System.Void SceneChanger::Update()
extern void SceneChanger_Update_m38073A08CB7CA40DA6F438B51BB023ADE9850D26 ();
// 0x0000004A System.Void SceneChanger::OnTriggerEnter(UnityEngine.Collider)
extern void SceneChanger_OnTriggerEnter_m7A0D73D85E8381280CF57E04388E9C0EF6276900 ();
// 0x0000004B System.Void SceneChanger::.ctor()
extern void SceneChanger__ctor_m067B4551AA6E9244ADE5C1640964819369FC7B9D ();
// 0x0000004C System.Void scenenum::.ctor()
extern void scenenum__ctor_m02602B84BE64B90A375F4A170B5C35EE04618A4D ();
// 0x0000004D System.Void colorSet::Start()
extern void colorSet_Start_mB33579D83877F0573E1F13579D43C7E28698F63F ();
// 0x0000004E System.Void colorSet::Update()
extern void colorSet_Update_m14A303B8A05B9A9B009C34D2391D15370BF60BBA ();
// 0x0000004F System.Void colorSet::.ctor()
extern void colorSet__ctor_mAF3DDD3F9F7B6043AA28CAD58CA37F2124AE39D9 ();
// 0x00000050 System.Void cube::Start()
extern void cube_Start_m689FB9A00C0F6C83C866C70D4F840AFBB2B8F9EB ();
// 0x00000051 System.Void cube::Update()
extern void cube_Update_mF5E92FAC1D93969DC78DC03DEB97C74413B07818 ();
// 0x00000052 System.Void cube::runCam(System.Single)
extern void cube_runCam_m39C9AF5C83E3F7B67A73485B5AED395DD335424B ();
// 0x00000053 System.Void cube::.ctor()
extern void cube__ctor_m2139AE0873B97EDD0E4B4CAF2220DDE3BFB6F3B5 ();
// 0x00000054 System.Void dissapearCube::Start()
extern void dissapearCube_Start_m92B4C28AFA016816039C3DCD0DB5F85EB4E72FF1 ();
// 0x00000055 System.Void dissapearCube::Update()
extern void dissapearCube_Update_m1DCCFB52C608435C37B16D40D617FAE2C904F9BF ();
// 0x00000056 System.Void dissapearCube::.ctor()
extern void dissapearCube__ctor_m58F9235B9DFF921C7188B3F5F0AD1B060CE9250E ();
// 0x00000057 System.Void key::Start()
extern void key_Start_m4E860FADDF15BEF705E805BDC79F842C280E7C5A ();
// 0x00000058 System.Void key::Update()
extern void key_Update_m39D0FE661E8D68AF17BF32F8830A9B9DD909A1C5 ();
// 0x00000059 System.Void key::.ctor()
extern void key__ctor_m59C74657F93DBA250DD38470CBBAF85967C6C38E ();
// 0x0000005A System.Void resultant::Start()
extern void resultant_Start_mC85EEF61A57F548361310D0F54113633AF16EEB4 ();
// 0x0000005B System.Void resultant::Update()
extern void resultant_Update_m4D07BE564B6A35FA7ECBFF85155DDF3103EDC8E2 ();
// 0x0000005C System.Void resultant::.ctor()
extern void resultant__ctor_mCCB6A48A460A83FF625DCAE6DCA3165B29302939 ();
// 0x0000005D System.Void ChatController::OnEnable()
extern void ChatController_OnEnable_mD13A02B63932BDA275E1A788FD72D86D69B9E440 ();
// 0x0000005E System.Void ChatController::OnDisable()
extern void ChatController_OnDisable_mD31D1ED1B2C3C82986BFBD18FA584D45167431F3 ();
// 0x0000005F System.Void ChatController::AddToChatOutput(System.String)
extern void ChatController_AddToChatOutput_m01CC3E959ACECC222DFD8541231EC1E00C024194 ();
// 0x00000060 System.Void ChatController::.ctor()
extern void ChatController__ctor_mF4343BA56301C6825EB0A71EBF9600525B437BCD ();
// 0x00000061 System.Void EnvMapAnimator::Awake()
extern void EnvMapAnimator_Awake_mAB3C67FA11192EFB31545F42D3D8AAB2A662FEB2 ();
// 0x00000062 System.Collections.IEnumerator EnvMapAnimator::Start()
extern void EnvMapAnimator_Start_m21098EFD0904DFD43A3CB2FF536E83F1593C2412 ();
// 0x00000063 System.Void EnvMapAnimator::.ctor()
extern void EnvMapAnimator__ctor_mBA9215F94AB29FBA4D3335AEA6FAB50567509E74 ();
// 0x00000064 System.Void Readme::.ctor()
extern void Readme__ctor_m23AE6143BDABB863B629ADE701E2998AB8651D4C ();
// 0x00000065 System.Char TMPro.TMP_DigitValidator::Validate(System.String&,System.Int32&,System.Char)
extern void TMP_DigitValidator_Validate_mD139A23C440A026E47FA8E3AD01AD6FEF7713C3D ();
// 0x00000066 System.Void TMPro.TMP_DigitValidator::.ctor()
extern void TMP_DigitValidator__ctor_mF6477F5EB75EC15CD6B81ACD85271F854BABC5D6 ();
// 0x00000067 System.Char TMPro.TMP_PhoneNumberValidator::Validate(System.String&,System.Int32&,System.Char)
extern void TMP_PhoneNumberValidator_Validate_mCA5EA200223A9F224F2F4DBD306DAE038C71A35F ();
// 0x00000068 System.Void TMPro.TMP_PhoneNumberValidator::.ctor()
extern void TMP_PhoneNumberValidator__ctor_mBB38130850945A40631821275F07C19720E0C55E ();
// 0x00000069 TMPro.TMP_TextEventHandler_CharacterSelectionEvent TMPro.TMP_TextEventHandler::get_onCharacterSelection()
extern void TMP_TextEventHandler_get_onCharacterSelection_mF70DBE3FF43B3D6E64053D37A2FADF802533E1FF ();
// 0x0000006A System.Void TMPro.TMP_TextEventHandler::set_onCharacterSelection(TMPro.TMP_TextEventHandler_CharacterSelectionEvent)
extern void TMP_TextEventHandler_set_onCharacterSelection_m237C99FE66E4E16518DAE68FF9CBF1A52E816AD2 ();
// 0x0000006B TMPro.TMP_TextEventHandler_SpriteSelectionEvent TMPro.TMP_TextEventHandler::get_onSpriteSelection()
extern void TMP_TextEventHandler_get_onSpriteSelection_m395603314F8CD073897DCAB5513270C6ADD94BF4 ();
// 0x0000006C System.Void TMPro.TMP_TextEventHandler::set_onSpriteSelection(TMPro.TMP_TextEventHandler_SpriteSelectionEvent)
extern void TMP_TextEventHandler_set_onSpriteSelection_mAAE4B440E34EE5736D43D6A8A7D3A7CEE0503D69 ();
// 0x0000006D TMPro.TMP_TextEventHandler_WordSelectionEvent TMPro.TMP_TextEventHandler::get_onWordSelection()
extern void TMP_TextEventHandler_get_onWordSelection_m415F4479934B1739658356B47DF4C2E90496AE2E ();
// 0x0000006E System.Void TMPro.TMP_TextEventHandler::set_onWordSelection(TMPro.TMP_TextEventHandler_WordSelectionEvent)
extern void TMP_TextEventHandler_set_onWordSelection_m6062C0AF2FDD8752DC4A75663EE8E5C128504698 ();
// 0x0000006F TMPro.TMP_TextEventHandler_LineSelectionEvent TMPro.TMP_TextEventHandler::get_onLineSelection()
extern void TMP_TextEventHandler_get_onLineSelection_m8E724700CC5DF1197B103F87156576A52F62AB2B ();
// 0x00000070 System.Void TMPro.TMP_TextEventHandler::set_onLineSelection(TMPro.TMP_TextEventHandler_LineSelectionEvent)
extern void TMP_TextEventHandler_set_onLineSelection_m1A8E37D2069EF684EF930D4F1ABE764AE17D9A62 ();
// 0x00000071 TMPro.TMP_TextEventHandler_LinkSelectionEvent TMPro.TMP_TextEventHandler::get_onLinkSelection()
extern void TMP_TextEventHandler_get_onLinkSelection_m221527467F0606DD3561E0FB0D7678AA8329AD5D ();
// 0x00000072 System.Void TMPro.TMP_TextEventHandler::set_onLinkSelection(TMPro.TMP_TextEventHandler_LinkSelectionEvent)
extern void TMP_TextEventHandler_set_onLinkSelection_m1376CC9B70177B0C25ACEDF91D5B94BC4B8CF71D ();
// 0x00000073 System.Void TMPro.TMP_TextEventHandler::Awake()
extern void TMP_TextEventHandler_Awake_m9A353CC9705A9E824A60C3D2D026A7FD96B41D74 ();
// 0x00000074 System.Void TMPro.TMP_TextEventHandler::LateUpdate()
extern void TMP_TextEventHandler_LateUpdate_m2F3241223A91F9C50E11B27F67BA2B6D19328B72 ();
// 0x00000075 System.Void TMPro.TMP_TextEventHandler::OnPointerEnter(UnityEngine.EventSystems.PointerEventData)
extern void TMP_TextEventHandler_OnPointerEnter_m1827A9D3F08839023DE71352202FE5F744E150EF ();
// 0x00000076 System.Void TMPro.TMP_TextEventHandler::OnPointerExit(UnityEngine.EventSystems.PointerEventData)
extern void TMP_TextEventHandler_OnPointerExit_m788B93D2C3B54BCF09475675B274BCB047D449FB ();
// 0x00000077 System.Void TMPro.TMP_TextEventHandler::SendOnCharacterSelection(System.Char,System.Int32)
extern void TMP_TextEventHandler_SendOnCharacterSelection_mBC44C107A6FB8C43F7C6629D4A15CA85471A28B2 ();
// 0x00000078 System.Void TMPro.TMP_TextEventHandler::SendOnSpriteSelection(System.Char,System.Int32)
extern void TMP_TextEventHandler_SendOnSpriteSelection_mEF24BCE06B0CE4450B6AE9561EC4B5052DAF00F6 ();
// 0x00000079 System.Void TMPro.TMP_TextEventHandler::SendOnWordSelection(System.String,System.Int32,System.Int32)
extern void TMP_TextEventHandler_SendOnWordSelection_m7C4D266070EE2ADC66BCCFD50EB74FEB4923B77E ();
// 0x0000007A System.Void TMPro.TMP_TextEventHandler::SendOnLineSelection(System.String,System.Int32,System.Int32)
extern void TMP_TextEventHandler_SendOnLineSelection_mAAF4AF44929D0C9FD73C89E5266028908074AEB1 ();
// 0x0000007B System.Void TMPro.TMP_TextEventHandler::SendOnLinkSelection(System.String,System.String,System.Int32)
extern void TMP_TextEventHandler_SendOnLinkSelection_m082D12F7D044456D8514E4D31944C6900F8262C0 ();
// 0x0000007C System.Void TMPro.TMP_TextEventHandler::.ctor()
extern void TMP_TextEventHandler__ctor_mEA56AE9489B50CF5E5FC682AA18D1CE9AF8E1F8B ();
// 0x0000007D System.Collections.IEnumerator TMPro.Examples.Benchmark01::Start()
extern void Benchmark01_Start_mC0055F208B85783F0B3DB942137439C897552571 ();
// 0x0000007E System.Void TMPro.Examples.Benchmark01::.ctor()
extern void Benchmark01__ctor_m2FA501D2C572C46A61635E0A3E2FF45EC3A3749C ();
// 0x0000007F System.Collections.IEnumerator TMPro.Examples.Benchmark01_UGUI::Start()
extern void Benchmark01_UGUI_Start_m976ED5172DEAFC628DE7C4C51DF25B1373C7846A ();
// 0x00000080 System.Void TMPro.Examples.Benchmark01_UGUI::.ctor()
extern void Benchmark01_UGUI__ctor_mD92CA5A254960EB149966C2A3243514596C96EAD ();
// 0x00000081 System.Void TMPro.Examples.Benchmark02::Start()
extern void Benchmark02_Start_m2D028BFC6EFB4C84C1A7A98B87A509B27E75BA06 ();
// 0x00000082 System.Void TMPro.Examples.Benchmark02::.ctor()
extern void Benchmark02__ctor_m7CA524C53D9E88510EE7987E680F49E8353E4B64 ();
// 0x00000083 System.Void TMPro.Examples.Benchmark03::Awake()
extern void Benchmark03_Awake_m8D1A987C39FD4756642011D01F35BDC3B1F99403 ();
// 0x00000084 System.Void TMPro.Examples.Benchmark03::Start()
extern void Benchmark03_Start_m73F65BA012D86A6BE17E82012AE8E2339CA5D550 ();
// 0x00000085 System.Void TMPro.Examples.Benchmark03::.ctor()
extern void Benchmark03__ctor_m9A5E67EA64AAC56D56C7D269CC9685E78276360A ();
// 0x00000086 System.Void TMPro.Examples.Benchmark04::Start()
extern void Benchmark04_Start_m22D98FCFC356D5CD7F401DE7EDCDAF7AE0219402 ();
// 0x00000087 System.Void TMPro.Examples.Benchmark04::.ctor()
extern void Benchmark04__ctor_mDAC3E3BE80C9236562EFB6E74DEBE67D8713101D ();
// 0x00000088 System.Void TMPro.Examples.CameraController::Awake()
extern void CameraController_Awake_m581B79998DB6946746CBF7380AFCC7F2B75D99F7 ();
// 0x00000089 System.Void TMPro.Examples.CameraController::Start()
extern void CameraController_Start_mA9D72DB0BB6E4F72192DA91BC9F8918A9C61B676 ();
// 0x0000008A System.Void TMPro.Examples.CameraController::LateUpdate()
extern void CameraController_LateUpdate_mDC862C8119AB0B4807245CC3482F027842EAB425 ();
// 0x0000008B System.Void TMPro.Examples.CameraController::GetPlayerInput()
extern void CameraController_GetPlayerInput_m198C209AC84EF7A2437ADB2B67F6B78D12AB9216 ();
// 0x0000008C System.Void TMPro.Examples.CameraController::.ctor()
extern void CameraController__ctor_m2108A608ABD8EA7FD2B47EE40C07F4117BB7607E ();
// 0x0000008D System.Void TMPro.Examples.ObjectSpin::Awake()
extern void ObjectSpin_Awake_mDA26D26457D277CC2D9042F3BD623D48849440C4 ();
// 0x0000008E System.Void TMPro.Examples.ObjectSpin::Update()
extern void ObjectSpin_Update_mC50AAC1AF75B07CD6753EA3224C369E43001791B ();
// 0x0000008F System.Void TMPro.Examples.ObjectSpin::.ctor()
extern void ObjectSpin__ctor_m2832B9D713355ECF861642D115F86AA64A6F119E ();
// 0x00000090 System.Void TMPro.Examples.ShaderPropAnimator::Awake()
extern void ShaderPropAnimator_Awake_m8E01638EBFE80CC0B9E4A97AB809B91E3C6956BE ();
// 0x00000091 System.Void TMPro.Examples.ShaderPropAnimator::Start()
extern void ShaderPropAnimator_Start_m24F4FADC328B0C76264DE24663CFA914EA94D1FD ();
// 0x00000092 System.Collections.IEnumerator TMPro.Examples.ShaderPropAnimator::AnimateProperties()
extern void ShaderPropAnimator_AnimateProperties_mC45F318132D23804CBF73EA2445EF7589C2333E9 ();
// 0x00000093 System.Void TMPro.Examples.ShaderPropAnimator::.ctor()
extern void ShaderPropAnimator__ctor_mC3894CE97A12F50FB225CA8F6F05A7B3CA4B0623 ();
// 0x00000094 System.Void TMPro.Examples.SimpleScript::Start()
extern void SimpleScript_Start_m22A3AE8E48128DF849EE2957F4EF881A433CA8CB ();
// 0x00000095 System.Void TMPro.Examples.SimpleScript::Update()
extern void SimpleScript_Update_m742F828A2245E8CC29BC045A999C5E527931DFF1 ();
// 0x00000096 System.Void TMPro.Examples.SimpleScript::.ctor()
extern void SimpleScript__ctor_mA2284F621031B4D494AC06B687AF43D2D1D89BD7 ();
// 0x00000097 System.Void TMPro.Examples.SkewTextExample::Awake()
extern void SkewTextExample_Awake_m51C217E0CB26C2E627BA01599147F69B893EF189 ();
// 0x00000098 System.Void TMPro.Examples.SkewTextExample::Start()
extern void SkewTextExample_Start_m6A9CEFA12DB252E297E41E256698DD4E90809F6A ();
// 0x00000099 UnityEngine.AnimationCurve TMPro.Examples.SkewTextExample::CopyAnimationCurve(UnityEngine.AnimationCurve)
extern void SkewTextExample_CopyAnimationCurve_m3CE7B666BEF4CFFE9EB110C8D57D9A5F6385720B ();
// 0x0000009A System.Collections.IEnumerator TMPro.Examples.SkewTextExample::WarpText()
extern void SkewTextExample_WarpText_m4A69C47EA665D49482B930F924E49C8E70FAC225 ();
// 0x0000009B System.Void TMPro.Examples.SkewTextExample::.ctor()
extern void SkewTextExample__ctor_m11DC90EB1A059F4201457E33C4422A7BDA90F099 ();
// 0x0000009C System.Void TMPro.Examples.TMP_ExampleScript_01::Awake()
extern void TMP_ExampleScript_01_Awake_m9CE8A9F929B99B2318A6F8598EE20E1D4E842ECD ();
// 0x0000009D System.Void TMPro.Examples.TMP_ExampleScript_01::Update()
extern void TMP_ExampleScript_01_Update_m8F48CBCC48D4CD26F731BA82ECBAC9DC0392AE0D ();
// 0x0000009E System.Void TMPro.Examples.TMP_ExampleScript_01::.ctor()
extern void TMP_ExampleScript_01__ctor_m9F5CE74EDA110F7539B4081CF3EE6B9FCF40D4A7 ();
// 0x0000009F System.Void TMPro.Examples.TMP_FrameRateCounter::Awake()
extern void TMP_FrameRateCounter_Awake_m906CC32CE5FE551DF29928581FFF7DE589C501F2 ();
// 0x000000A0 System.Void TMPro.Examples.TMP_FrameRateCounter::Start()
extern void TMP_FrameRateCounter_Start_m614FA9DE53ECB1CF4C6AF6BBC58CE35CA904EB32 ();
// 0x000000A1 System.Void TMPro.Examples.TMP_FrameRateCounter::Update()
extern void TMP_FrameRateCounter_Update_m16AB65EF6AB38F237F5A6D2D412AB7E5BF7B1349 ();
// 0x000000A2 System.Void TMPro.Examples.TMP_FrameRateCounter::Set_FrameCounter_Position(TMPro.Examples.TMP_FrameRateCounter_FpsCounterAnchorPositions)
extern void TMP_FrameRateCounter_Set_FrameCounter_Position_m537A709F25C3AA752437A025BEE741BD2F71320E ();
// 0x000000A3 System.Void TMPro.Examples.TMP_FrameRateCounter::.ctor()
extern void TMP_FrameRateCounter__ctor_mD86AC3A8D918D14200BF80A354E0E43DC5A565A2 ();
// 0x000000A4 System.Void TMPro.Examples.TMP_TextEventCheck::OnEnable()
extern void TMP_TextEventCheck_OnEnable_m22D9B03F3E1269B8B104E76DA083ED105029258A ();
// 0x000000A5 System.Void TMPro.Examples.TMP_TextEventCheck::OnDisable()
extern void TMP_TextEventCheck_OnDisable_m42813B343A1FDD155C6BFBFCB514E084FB528DA0 ();
// 0x000000A6 System.Void TMPro.Examples.TMP_TextEventCheck::OnCharacterSelection(System.Char,System.Int32)
extern void TMP_TextEventCheck_OnCharacterSelection_mC6992B7B1B6A441DEC5315185E3CE022BB567D61 ();
// 0x000000A7 System.Void TMPro.Examples.TMP_TextEventCheck::OnSpriteSelection(System.Char,System.Int32)
extern void TMP_TextEventCheck_OnSpriteSelection_mEC541297C2228C26AB54F825705F0476D45F877A ();
// 0x000000A8 System.Void TMPro.Examples.TMP_TextEventCheck::OnWordSelection(System.String,System.Int32,System.Int32)
extern void TMP_TextEventCheck_OnWordSelection_mA1170F805C77CC89B818D8FBEE533846AF66509C ();
// 0x000000A9 System.Void TMPro.Examples.TMP_TextEventCheck::OnLineSelection(System.String,System.Int32,System.Int32)
extern void TMP_TextEventCheck_OnLineSelection_mB871339347DCB016E019F509A00BDE9A58105822 ();
// 0x000000AA System.Void TMPro.Examples.TMP_TextEventCheck::OnLinkSelection(System.String,System.String,System.Int32)
extern void TMP_TextEventCheck_OnLinkSelection_m44A79DDBDF03F254BAFB97BE3E42845B769136C5 ();
// 0x000000AB System.Void TMPro.Examples.TMP_TextEventCheck::.ctor()
extern void TMP_TextEventCheck__ctor_mA67343988C9E9B71C981A9FFAD620C4A9A6AA267 ();
// 0x000000AC System.Void TMPro.Examples.TMP_TextInfoDebugTool::.ctor()
extern void TMP_TextInfoDebugTool__ctor_m1EA6A5E31F88A1C7E20167A3BCCE427E9E828116 ();
// 0x000000AD System.Void TMPro.Examples.TMP_TextSelector_A::Awake()
extern void TMP_TextSelector_A_Awake_m82972EF3AF67EAAFD94A5EE3EA852CE15BE37FC1 ();
// 0x000000AE System.Void TMPro.Examples.TMP_TextSelector_A::LateUpdate()
extern void TMP_TextSelector_A_LateUpdate_m40594D716F53E6E5BC0ECD2FFE8ECA44FAA5C8E4 ();
// 0x000000AF System.Void TMPro.Examples.TMP_TextSelector_A::OnPointerEnter(UnityEngine.EventSystems.PointerEventData)
extern void TMP_TextSelector_A_OnPointerEnter_m8462C2DC4F71BDE295BE446B213B73F78442E264 ();
// 0x000000B0 System.Void TMPro.Examples.TMP_TextSelector_A::OnPointerExit(UnityEngine.EventSystems.PointerEventData)
extern void TMP_TextSelector_A_OnPointerExit_m3AC7467ECE689A58590DA325F8B300B08C1E1B5D ();
// 0x000000B1 System.Void TMPro.Examples.TMP_TextSelector_A::.ctor()
extern void TMP_TextSelector_A__ctor_m081D44F31AA16E345F914869A07BD47D118707DF ();
// 0x000000B2 System.Void TMPro.Examples.TMP_TextSelector_B::Awake()
extern void TMP_TextSelector_B_Awake_m217B6E2FC4029A304908EE9DC1E4AA2885CBF8A3 ();
// 0x000000B3 System.Void TMPro.Examples.TMP_TextSelector_B::OnEnable()
extern void TMP_TextSelector_B_OnEnable_m24A7CCA0D93F17AC1A12A340277C706B5C2F9BAB ();
// 0x000000B4 System.Void TMPro.Examples.TMP_TextSelector_B::OnDisable()
extern void TMP_TextSelector_B_OnDisable_m6088452529A70A6684BD8936872B71451779A2F4 ();
// 0x000000B5 System.Void TMPro.Examples.TMP_TextSelector_B::ON_TEXT_CHANGED(UnityEngine.Object)
extern void TMP_TextSelector_B_ON_TEXT_CHANGED_m79EEE4DF7792F553F5DEDCF0094DAC6F2A58137A ();
// 0x000000B6 System.Void TMPro.Examples.TMP_TextSelector_B::LateUpdate()
extern void TMP_TextSelector_B_LateUpdate_m745577078D86EF6C23B914BD03EA1A1D169B9B7B ();
// 0x000000B7 System.Void TMPro.Examples.TMP_TextSelector_B::OnPointerEnter(UnityEngine.EventSystems.PointerEventData)
extern void TMP_TextSelector_B_OnPointerEnter_mF6C09A2C64F5D2619014ADD50039358FAD24DB3E ();
// 0x000000B8 System.Void TMPro.Examples.TMP_TextSelector_B::OnPointerExit(UnityEngine.EventSystems.PointerEventData)
extern void TMP_TextSelector_B_OnPointerExit_mB0AAA8D034FC575EB3BCF7B0D4514BD110178AD3 ();
// 0x000000B9 System.Void TMPro.Examples.TMP_TextSelector_B::OnPointerClick(UnityEngine.EventSystems.PointerEventData)
extern void TMP_TextSelector_B_OnPointerClick_m13B20506F762769F099DE10B3CCA2DF194192B42 ();
// 0x000000BA System.Void TMPro.Examples.TMP_TextSelector_B::OnPointerUp(UnityEngine.EventSystems.PointerEventData)
extern void TMP_TextSelector_B_OnPointerUp_mD53FD60E0C5930231FB16BDEA37165FF46D85F6E ();
// 0x000000BB System.Void TMPro.Examples.TMP_TextSelector_B::RestoreCachedVertexAttributes(System.Int32)
extern void TMP_TextSelector_B_RestoreCachedVertexAttributes_m1D03D0E14D6054D292334C19030256B666ACDA0E ();
// 0x000000BC System.Void TMPro.Examples.TMP_TextSelector_B::.ctor()
extern void TMP_TextSelector_B__ctor_m494C501CF565B1ED7C8CB2951EB6FB4F8505637F ();
// 0x000000BD System.Void TMPro.Examples.TMP_UiFrameRateCounter::Awake()
extern void TMP_UiFrameRateCounter_Awake_m255A7821E5BA4A7A75B9276E07BC9EA7331B5AA6 ();
// 0x000000BE System.Void TMPro.Examples.TMP_UiFrameRateCounter::Start()
extern void TMP_UiFrameRateCounter_Start_mA4A02EB5C853A44F251F43F0AD5967AE914E2B0F ();
// 0x000000BF System.Void TMPro.Examples.TMP_UiFrameRateCounter::Update()
extern void TMP_UiFrameRateCounter_Update_m04555F8DF147C553FA2D59E33E744901D811B615 ();
// 0x000000C0 System.Void TMPro.Examples.TMP_UiFrameRateCounter::Set_FrameCounter_Position(TMPro.Examples.TMP_UiFrameRateCounter_FpsCounterAnchorPositions)
extern void TMP_UiFrameRateCounter_Set_FrameCounter_Position_mDF0FDFBCD11955E0E1D1C9E961B6AD0690C669ED ();
// 0x000000C1 System.Void TMPro.Examples.TMP_UiFrameRateCounter::.ctor()
extern void TMP_UiFrameRateCounter__ctor_m99ACA1D2410917C5837321FC5AC84EAED676D4CC ();
// 0x000000C2 System.Void TMPro.Examples.TMPro_InstructionOverlay::Awake()
extern void TMPro_InstructionOverlay_Awake_m639E300B56757BDB94766447365E1C94B5B83ACD ();
// 0x000000C3 System.Void TMPro.Examples.TMPro_InstructionOverlay::Set_FrameCounter_Position(TMPro.Examples.TMPro_InstructionOverlay_FpsCounterAnchorPositions)
extern void TMPro_InstructionOverlay_Set_FrameCounter_Position_m74B8F0AE15DA6C9968C482981EBCF5CC9DB1F43D ();
// 0x000000C4 System.Void TMPro.Examples.TMPro_InstructionOverlay::.ctor()
extern void TMPro_InstructionOverlay__ctor_m570C4B4CB3126622D6DFF71158336313C45C717A ();
// 0x000000C5 System.Void TMPro.Examples.TeleType::Awake()
extern void TeleType_Awake_m5F758974DA88ED8187E71A5100D2D9E47985E359 ();
// 0x000000C6 System.Collections.IEnumerator TMPro.Examples.TeleType::Start()
extern void TeleType_Start_mC32B726B6202883E12E1A62A52E50092E7E9D9F0 ();
// 0x000000C7 System.Void TMPro.Examples.TeleType::.ctor()
extern void TeleType__ctor_m6CDFDC88D47FE66021C133974C8CB0E16B08A00E ();
// 0x000000C8 System.Void TMPro.Examples.TextConsoleSimulator::Awake()
extern void TextConsoleSimulator_Awake_m4F61F06DFE11CFAF9B064CCA5B2D6423D5CFC302 ();
// 0x000000C9 System.Void TMPro.Examples.TextConsoleSimulator::Start()
extern void TextConsoleSimulator_Start_m572903C9070A8AD276D2CB14DF7659AE551C75B3 ();
// 0x000000CA System.Void TMPro.Examples.TextConsoleSimulator::OnEnable()
extern void TextConsoleSimulator_OnEnable_m1A36B043E4EDD945C93DFC49F7FAFB7034728593 ();
// 0x000000CB System.Void TMPro.Examples.TextConsoleSimulator::OnDisable()
extern void TextConsoleSimulator_OnDisable_m6F9BE1975CB15EE559D3B617E8972C8812B41325 ();
// 0x000000CC System.Void TMPro.Examples.TextConsoleSimulator::ON_TEXT_CHANGED(UnityEngine.Object)
extern void TextConsoleSimulator_ON_TEXT_CHANGED_m73C6B3DAA27778B666B9B3B75C9D4641FC1BEC8A ();
// 0x000000CD System.Collections.IEnumerator TMPro.Examples.TextConsoleSimulator::RevealCharacters(TMPro.TMP_Text)
extern void TextConsoleSimulator_RevealCharacters_mC24F1D67B99F0AFE7535143BB60C530C8E8735F0 ();
// 0x000000CE System.Collections.IEnumerator TMPro.Examples.TextConsoleSimulator::RevealWords(TMPro.TMP_Text)
extern void TextConsoleSimulator_RevealWords_m68CAA9BDC1DF3454ECB7C5496A5A2020F84027B8 ();
// 0x000000CF System.Void TMPro.Examples.TextConsoleSimulator::.ctor()
extern void TextConsoleSimulator__ctor_m4DB9B9E3836D192AA7F42B7EBDC31883E39610E9 ();
// 0x000000D0 System.Void TMPro.Examples.TextMeshProFloatingText::Awake()
extern void TextMeshProFloatingText_Awake_mD99CC6A70945373DA699327F5A0D0C4516A7D02A ();
// 0x000000D1 System.Void TMPro.Examples.TextMeshProFloatingText::Start()
extern void TextMeshProFloatingText_Start_m3286BB7639F6042AD4437D41BF4633326C4290BE ();
// 0x000000D2 System.Collections.IEnumerator TMPro.Examples.TextMeshProFloatingText::DisplayTextMeshProFloatingText()
extern void TextMeshProFloatingText_DisplayTextMeshProFloatingText_m61ABFBAA95ED83A248FBCC3F5823907824434D34 ();
// 0x000000D3 System.Collections.IEnumerator TMPro.Examples.TextMeshProFloatingText::DisplayTextMeshFloatingText()
extern void TextMeshProFloatingText_DisplayTextMeshFloatingText_m65A61DF0BA640F2787DD87E93B8FD9DEC14AACB4 ();
// 0x000000D4 System.Void TMPro.Examples.TextMeshProFloatingText::.ctor()
extern void TextMeshProFloatingText__ctor_m11DBC535BA8001B48A06F61515C0787C3A86611F ();
// 0x000000D5 System.Void TMPro.Examples.TextMeshSpawner::Awake()
extern void TextMeshSpawner_Awake_mB3C405B4856E9B437E13E4BD85DAE73FFF1F6561 ();
// 0x000000D6 System.Void TMPro.Examples.TextMeshSpawner::Start()
extern void TextMeshSpawner_Start_m436D4CD2A82C0F95B8D942DF4CCFCE09792EDF0F ();
// 0x000000D7 System.Void TMPro.Examples.TextMeshSpawner::.ctor()
extern void TextMeshSpawner__ctor_mDB693DABF1C3BA92B7A3A4E1460F28E3FAFB444D ();
// 0x000000D8 System.Void TMPro.Examples.VertexColorCycler::Awake()
extern void VertexColorCycler_Awake_mAEEAA831C084B447DFD0C91A5FA606CB26D3E22A ();
// 0x000000D9 System.Void TMPro.Examples.VertexColorCycler::Start()
extern void VertexColorCycler_Start_mF01B64B3E5FE5B648DE2EED031962D9183C2D238 ();
// 0x000000DA System.Collections.IEnumerator TMPro.Examples.VertexColorCycler::AnimateVertexColors()
extern void VertexColorCycler_AnimateVertexColors_m9CDB87631C324FB89FA7D52F5BC910146F3DDEB7 ();
// 0x000000DB System.Void TMPro.Examples.VertexColorCycler::.ctor()
extern void VertexColorCycler__ctor_m9B68D69B87E07DC0154344E5276EFC5B11205718 ();
// 0x000000DC System.Void TMPro.Examples.VertexJitter::Awake()
extern void VertexJitter_Awake_m9699A62E72D3A262EDFDF7AC63ABD33E53F179B6 ();
// 0x000000DD System.Void TMPro.Examples.VertexJitter::OnEnable()
extern void VertexJitter_OnEnable_m1B592E7AC81C7F17D0A59325EBDE71E067178E8A ();
// 0x000000DE System.Void TMPro.Examples.VertexJitter::OnDisable()
extern void VertexJitter_OnDisable_m5567B541D1602AD54B0F437D4710BCD1951FE2C5 ();
// 0x000000DF System.Void TMPro.Examples.VertexJitter::Start()
extern void VertexJitter_Start_mB698E212B8C3B7C66C71C88F4761A4F33FCE4683 ();
// 0x000000E0 System.Void TMPro.Examples.VertexJitter::ON_TEXT_CHANGED(UnityEngine.Object)
extern void VertexJitter_ON_TEXT_CHANGED_m09CFD4E872042E7377BEC8B95D34F22F62ABC45B ();
// 0x000000E1 System.Collections.IEnumerator TMPro.Examples.VertexJitter::AnimateVertexColors()
extern void VertexJitter_AnimateVertexColors_m1CCF60CA14B2FF530950D366FF078281ADC48FF4 ();
// 0x000000E2 System.Void TMPro.Examples.VertexJitter::.ctor()
extern void VertexJitter__ctor_mC19C148659C8C97357DB56F36E14914133DA93CF ();
// 0x000000E3 System.Void TMPro.Examples.VertexShakeA::Awake()
extern void VertexShakeA_Awake_mD2ABEB338822E0DBCFDEC1DB46EC20BB2C44A8C2 ();
// 0x000000E4 System.Void TMPro.Examples.VertexShakeA::OnEnable()
extern void VertexShakeA_OnEnable_m60947EACA10408B6EAD2EC7AC77B4E54E2666DD8 ();
// 0x000000E5 System.Void TMPro.Examples.VertexShakeA::OnDisable()
extern void VertexShakeA_OnDisable_mF5AF9069E523C0DF610EF3BE2017E73A4609E3CC ();
// 0x000000E6 System.Void TMPro.Examples.VertexShakeA::Start()
extern void VertexShakeA_Start_m96D17C13A279F9B442588F6448672BCF07E4A409 ();
// 0x000000E7 System.Void TMPro.Examples.VertexShakeA::ON_TEXT_CHANGED(UnityEngine.Object)
extern void VertexShakeA_ON_TEXT_CHANGED_mE761EE13D2F9573841EFA5DEE82E545545280BFA ();
// 0x000000E8 System.Collections.IEnumerator TMPro.Examples.VertexShakeA::AnimateVertexColors()
extern void VertexShakeA_AnimateVertexColors_mC97FED540BDE59254AB30C5E6BCF1F53B766945F ();
// 0x000000E9 System.Void TMPro.Examples.VertexShakeA::.ctor()
extern void VertexShakeA__ctor_mD84B9A0167705D5D3C8CA024D479DC7B5362E67B ();
// 0x000000EA System.Void TMPro.Examples.VertexShakeB::Awake()
extern void VertexShakeB_Awake_mA59F3CA197B3A474F4D795E2B3F182179FF633CF ();
// 0x000000EB System.Void TMPro.Examples.VertexShakeB::OnEnable()
extern void VertexShakeB_OnEnable_m8D4DD5CA81E5B0C02937D43C1782533D54F34B3F ();
// 0x000000EC System.Void TMPro.Examples.VertexShakeB::OnDisable()
extern void VertexShakeB_OnDisable_m4473873008D4A843A26F0D2353FC36ABE74CEED2 ();
// 0x000000ED System.Void TMPro.Examples.VertexShakeB::Start()
extern void VertexShakeB_Start_m24BEF670ABD1CCC864FAFE04750FEB83D916D0DF ();
// 0x000000EE System.Void TMPro.Examples.VertexShakeB::ON_TEXT_CHANGED(UnityEngine.Object)
extern void VertexShakeB_ON_TEXT_CHANGED_mCC864EE9569AF68F53F6EAEB2CE8077CFEAF9E53 ();
// 0x000000EF System.Collections.IEnumerator TMPro.Examples.VertexShakeB::AnimateVertexColors()
extern void VertexShakeB_AnimateVertexColors_mAF3B23F4DD98AC3E641700B994B2994C14F0E12C ();
// 0x000000F0 System.Void TMPro.Examples.VertexShakeB::.ctor()
extern void VertexShakeB__ctor_mDCAEC737A20F161914DD12A2FCBAB6AB7C64FEF2 ();
// 0x000000F1 System.Void TMPro.Examples.VertexZoom::Awake()
extern void VertexZoom_Awake_m5F98434E568929859E250743BA214C0782D17F2B ();
// 0x000000F2 System.Void TMPro.Examples.VertexZoom::OnEnable()
extern void VertexZoom_OnEnable_m01E35B4259BA0B13EC5DA18A11535C2EC6344123 ();
// 0x000000F3 System.Void TMPro.Examples.VertexZoom::OnDisable()
extern void VertexZoom_OnDisable_mACD450919605863EC4C36DA360898BAEBBF3DDDB ();
// 0x000000F4 System.Void TMPro.Examples.VertexZoom::Start()
extern void VertexZoom_Start_m6910FF4AC88466E3B7DB867AD553429F1745320D ();
// 0x000000F5 System.Void TMPro.Examples.VertexZoom::ON_TEXT_CHANGED(UnityEngine.Object)
extern void VertexZoom_ON_TEXT_CHANGED_mBFB58FE53145750AD747B38D9D1E7E00F8DBF9A0 ();
// 0x000000F6 System.Collections.IEnumerator TMPro.Examples.VertexZoom::AnimateVertexColors()
extern void VertexZoom_AnimateVertexColors_m328088EC0F893B3E60BB072F77ADF939B8566E4D ();
// 0x000000F7 System.Void TMPro.Examples.VertexZoom::.ctor()
extern void VertexZoom__ctor_m67833553C2739616BF059C661F92A032885510B2 ();
// 0x000000F8 System.Void TMPro.Examples.WarpTextExample::Awake()
extern void WarpTextExample_Awake_m9643904751E2DF0A7DF536847AEA1A2B0774DD20 ();
// 0x000000F9 System.Void TMPro.Examples.WarpTextExample::Start()
extern void WarpTextExample_Start_mDF931C271901519BF21FD356F706FA8CDE236406 ();
// 0x000000FA UnityEngine.AnimationCurve TMPro.Examples.WarpTextExample::CopyAnimationCurve(UnityEngine.AnimationCurve)
extern void WarpTextExample_CopyAnimationCurve_m2C738EA265E2B35868110EE1D8FCBD4F1D61C038 ();
// 0x000000FB System.Collections.IEnumerator TMPro.Examples.WarpTextExample::WarpText()
extern void WarpTextExample_WarpText_mAAAB1687869E0121C858C65BDB2D294D55CFB67A ();
// 0x000000FC System.Void TMPro.Examples.WarpTextExample::.ctor()
extern void WarpTextExample__ctor_mC3EAA1AE81FB3DA4B25F20E557EC6627A06DCB31 ();
// 0x000000FD System.Void UnityTemplateProjects.SimpleCameraController::OnEnable()
extern void SimpleCameraController_OnEnable_mE3D6E47455F101F2DEEBC2A58D09A97CF38E80B8 ();
// 0x000000FE UnityEngine.Vector3 UnityTemplateProjects.SimpleCameraController::GetInputTranslationDirection()
extern void SimpleCameraController_GetInputTranslationDirection_m73C99DB69CEB467834BBA00A62415D1CEEF0CB47 ();
// 0x000000FF System.Void UnityTemplateProjects.SimpleCameraController::Update()
extern void SimpleCameraController_Update_mBCD24408A4A2C4053F2F98DB808BD6DE88CA998F ();
// 0x00000100 System.Void UnityTemplateProjects.SimpleCameraController::.ctor()
extern void SimpleCameraController__ctor_m8DE12FC1A6C31D2D60ED78F0B574CE3F864F546E ();
// 0x00000101 System.Void EnvMapAnimator_<Start>d__4::.ctor(System.Int32)
extern void U3CStartU3Ed__4__ctor_m004DF17C34E6A9C76325BD4C65E0F328AD4B37E0 ();
// 0x00000102 System.Void EnvMapAnimator_<Start>d__4::System.IDisposable.Dispose()
extern void U3CStartU3Ed__4_System_IDisposable_Dispose_mE7E20C5789828A8FDE263BD5ACC2D02982334B46 ();
// 0x00000103 System.Boolean EnvMapAnimator_<Start>d__4::MoveNext()
extern void U3CStartU3Ed__4_MoveNext_mB3F55ABCABBA6717942BDC85935FDE439D09E226 ();
// 0x00000104 System.Object EnvMapAnimator_<Start>d__4::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CStartU3Ed__4_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mF976D094846BDC403335C76F41CAC26D53C8F1D2 ();
// 0x00000105 System.Void EnvMapAnimator_<Start>d__4::System.Collections.IEnumerator.Reset()
extern void U3CStartU3Ed__4_System_Collections_IEnumerator_Reset_m9368B3951732B0D18993DA1B889346A775F252CE ();
// 0x00000106 System.Object EnvMapAnimator_<Start>d__4::System.Collections.IEnumerator.get_Current()
extern void U3CStartU3Ed__4_System_Collections_IEnumerator_get_Current_m495592283D84E6B446F7B9B7405F250D9687DEFB ();
// 0x00000107 System.Void Readme_Section::.ctor()
extern void Section__ctor_mE73C1D6AE5454B5A67AAB04CAA5144A5CA0B0D96 ();
// 0x00000108 System.Void TMPro.TMP_TextEventHandler_CharacterSelectionEvent::.ctor()
extern void CharacterSelectionEvent__ctor_m036DA7F340B0839696EB50045AB186BD1046BE85 ();
// 0x00000109 System.Void TMPro.TMP_TextEventHandler_SpriteSelectionEvent::.ctor()
extern void SpriteSelectionEvent__ctor_m0BC042938C4EBBB77FFAD68C1ACD74FC1C3C1052 ();
// 0x0000010A System.Void TMPro.TMP_TextEventHandler_WordSelectionEvent::.ctor()
extern void WordSelectionEvent__ctor_m1C01733FD9860337084DFE63607ECE0EF8A450EA ();
// 0x0000010B System.Void TMPro.TMP_TextEventHandler_LineSelectionEvent::.ctor()
extern void LineSelectionEvent__ctor_m1C3A0C84C5C0FEA6C33FA9ED99756A85363C9EF2 ();
// 0x0000010C System.Void TMPro.TMP_TextEventHandler_LinkSelectionEvent::.ctor()
extern void LinkSelectionEvent__ctor_mC7034F51586C51D1DE381F6222816DC1542AFF3A ();
// 0x0000010D System.Void TMPro.Examples.Benchmark01_<Start>d__10::.ctor(System.Int32)
extern void U3CStartU3Ed__10__ctor_m139DF863E59AD287A6C14228BB59D56E7FD2E578 ();
// 0x0000010E System.Void TMPro.Examples.Benchmark01_<Start>d__10::System.IDisposable.Dispose()
extern void U3CStartU3Ed__10_System_IDisposable_Dispose_mBBFAE2F68813477259A0B665B4E81833C03C746B ();
// 0x0000010F System.Boolean TMPro.Examples.Benchmark01_<Start>d__10::MoveNext()
extern void U3CStartU3Ed__10_MoveNext_m8D27A150B4BC045DD5A1ACB2FABBB7F7F318A015 ();
// 0x00000110 System.Object TMPro.Examples.Benchmark01_<Start>d__10::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CStartU3Ed__10_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m9C55687F407BA372889D6A533FB817E1EA81C165 ();
// 0x00000111 System.Void TMPro.Examples.Benchmark01_<Start>d__10::System.Collections.IEnumerator.Reset()
extern void U3CStartU3Ed__10_System_Collections_IEnumerator_Reset_mE725DFFE744FAEDABF70579D04BBEB17A6CFF692 ();
// 0x00000112 System.Object TMPro.Examples.Benchmark01_<Start>d__10::System.Collections.IEnumerator.get_Current()
extern void U3CStartU3Ed__10_System_Collections_IEnumerator_get_Current_mD8EEDE3D2E1E9838472D20AE93DD750D1EE39AF8 ();
// 0x00000113 System.Void TMPro.Examples.Benchmark01_UGUI_<Start>d__10::.ctor(System.Int32)
extern void U3CStartU3Ed__10__ctor_mECD4DB9695B4D04CEF08DF193DAFA21412DA40EF ();
// 0x00000114 System.Void TMPro.Examples.Benchmark01_UGUI_<Start>d__10::System.IDisposable.Dispose()
extern void U3CStartU3Ed__10_System_IDisposable_Dispose_m6773C67C5C6E7E52F8C8545181173A58A6B7D939 ();
// 0x00000115 System.Boolean TMPro.Examples.Benchmark01_UGUI_<Start>d__10::MoveNext()
extern void U3CStartU3Ed__10_MoveNext_mB823F98B1B0907B6959EAEE4D1EBE0AA35795EA3 ();
// 0x00000116 System.Object TMPro.Examples.Benchmark01_UGUI_<Start>d__10::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CStartU3Ed__10_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mF100CFC13DED969B3BBE2007B3F863DCE919D978 ();
// 0x00000117 System.Void TMPro.Examples.Benchmark01_UGUI_<Start>d__10::System.Collections.IEnumerator.Reset()
extern void U3CStartU3Ed__10_System_Collections_IEnumerator_Reset_mDE1D3A30ECA00E3CA2218A582F2C87EEE082E2DB ();
// 0x00000118 System.Object TMPro.Examples.Benchmark01_UGUI_<Start>d__10::System.Collections.IEnumerator.get_Current()
extern void U3CStartU3Ed__10_System_Collections_IEnumerator_get_Current_m13710692FCBB7BB736B1F6446778124064802C83 ();
// 0x00000119 System.Void TMPro.Examples.ShaderPropAnimator_<AnimateProperties>d__6::.ctor(System.Int32)
extern void U3CAnimatePropertiesU3Ed__6__ctor_mB4DA3EEEFC5ECB8376EF29EAC034162B575961B8 ();
// 0x0000011A System.Void TMPro.Examples.ShaderPropAnimator_<AnimateProperties>d__6::System.IDisposable.Dispose()
extern void U3CAnimatePropertiesU3Ed__6_System_IDisposable_Dispose_mC6A68A27A902E234429E3706D6DB432BEA04A384 ();
// 0x0000011B System.Boolean TMPro.Examples.ShaderPropAnimator_<AnimateProperties>d__6::MoveNext()
extern void U3CAnimatePropertiesU3Ed__6_MoveNext_mDE142F6B3AAB5916834A6820A5E7B13A7B71E822 ();
// 0x0000011C System.Object TMPro.Examples.ShaderPropAnimator_<AnimateProperties>d__6::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CAnimatePropertiesU3Ed__6_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m9F4D59DDC372B977CD7297AA5F0C83D4FFBBA830 ();
// 0x0000011D System.Void TMPro.Examples.ShaderPropAnimator_<AnimateProperties>d__6::System.Collections.IEnumerator.Reset()
extern void U3CAnimatePropertiesU3Ed__6_System_Collections_IEnumerator_Reset_mAC1E960F7FFCF032EE668635835954377D1469F6 ();
// 0x0000011E System.Object TMPro.Examples.ShaderPropAnimator_<AnimateProperties>d__6::System.Collections.IEnumerator.get_Current()
extern void U3CAnimatePropertiesU3Ed__6_System_Collections_IEnumerator_get_Current_m96B6B8A0D715268DB789F3D4C60FC6DEC9E1F6E6 ();
// 0x0000011F System.Void TMPro.Examples.SkewTextExample_<WarpText>d__7::.ctor(System.Int32)
extern void U3CWarpTextU3Ed__7__ctor_m07871FDF578BC130082658B43FB4322C15F0909E ();
// 0x00000120 System.Void TMPro.Examples.SkewTextExample_<WarpText>d__7::System.IDisposable.Dispose()
extern void U3CWarpTextU3Ed__7_System_IDisposable_Dispose_m3C8BC1501397E256464ADD27A32486CDE63C2BE2 ();
// 0x00000121 System.Boolean TMPro.Examples.SkewTextExample_<WarpText>d__7::MoveNext()
extern void U3CWarpTextU3Ed__7_MoveNext_m11D4701B069FCFC106319CBDCA56244EFA4C795F ();
// 0x00000122 System.Object TMPro.Examples.SkewTextExample_<WarpText>d__7::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CWarpTextU3Ed__7_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m995FCE4A3B9B270605168D01EF7439A437864C06 ();
// 0x00000123 System.Void TMPro.Examples.SkewTextExample_<WarpText>d__7::System.Collections.IEnumerator.Reset()
extern void U3CWarpTextU3Ed__7_System_Collections_IEnumerator_Reset_m9970CA113E1A293472987C004B42771993CAA05C ();
// 0x00000124 System.Object TMPro.Examples.SkewTextExample_<WarpText>d__7::System.Collections.IEnumerator.get_Current()
extern void U3CWarpTextU3Ed__7_System_Collections_IEnumerator_get_Current_m398E9D0D09F26D5C3268EB41936ED92240474910 ();
// 0x00000125 System.Void TMPro.Examples.TeleType_<Start>d__4::.ctor(System.Int32)
extern void U3CStartU3Ed__4__ctor_mFB2D6F55665AAA83D38C58F58FA9DD0F5CE51351 ();
// 0x00000126 System.Void TMPro.Examples.TeleType_<Start>d__4::System.IDisposable.Dispose()
extern void U3CStartU3Ed__4_System_IDisposable_Dispose_m72D91E3700B8E1F2053A7620793F97E01C1A2E3A ();
// 0x00000127 System.Boolean TMPro.Examples.TeleType_<Start>d__4::MoveNext()
extern void U3CStartU3Ed__4_MoveNext_m2839A135AFB4518430283897981AF4C91ABDBC6A ();
// 0x00000128 System.Object TMPro.Examples.TeleType_<Start>d__4::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CStartU3Ed__4_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mB3E80ED07333F946FC221C16A77997DF51A80F87 ();
// 0x00000129 System.Void TMPro.Examples.TeleType_<Start>d__4::System.Collections.IEnumerator.Reset()
extern void U3CStartU3Ed__4_System_Collections_IEnumerator_Reset_mAC8E620F4FCE24A409840017FB003AA1048497EF ();
// 0x0000012A System.Object TMPro.Examples.TeleType_<Start>d__4::System.Collections.IEnumerator.get_Current()
extern void U3CStartU3Ed__4_System_Collections_IEnumerator_get_Current_mD6DFD0886CCA250CB95B2828DEEEEE5EA6DC303A ();
// 0x0000012B System.Void TMPro.Examples.TextConsoleSimulator_<RevealCharacters>d__7::.ctor(System.Int32)
extern void U3CRevealCharactersU3Ed__7__ctor_mAF579198F26F3FD002CB7F4919CCB513E2B770E1 ();
// 0x0000012C System.Void TMPro.Examples.TextConsoleSimulator_<RevealCharacters>d__7::System.IDisposable.Dispose()
extern void U3CRevealCharactersU3Ed__7_System_IDisposable_Dispose_m2B3AB12689498DE28F90CF5DA3D40AA6C31B928E ();
// 0x0000012D System.Boolean TMPro.Examples.TextConsoleSimulator_<RevealCharacters>d__7::MoveNext()
extern void U3CRevealCharactersU3Ed__7_MoveNext_m16C2594A51B9D102B30646C47111F3476FFBF311 ();
// 0x0000012E System.Object TMPro.Examples.TextConsoleSimulator_<RevealCharacters>d__7::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CRevealCharactersU3Ed__7_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m8B5325041D4E4A3F3D5575373F25A93752D9E514 ();
// 0x0000012F System.Void TMPro.Examples.TextConsoleSimulator_<RevealCharacters>d__7::System.Collections.IEnumerator.Reset()
extern void U3CRevealCharactersU3Ed__7_System_Collections_IEnumerator_Reset_m321E1A1FD7DE7840F8433BF739D3E889FB3E9C7C ();
// 0x00000130 System.Object TMPro.Examples.TextConsoleSimulator_<RevealCharacters>d__7::System.Collections.IEnumerator.get_Current()
extern void U3CRevealCharactersU3Ed__7_System_Collections_IEnumerator_get_Current_m9CF6271A74900FFA5BD4027E84D63C164C1650BC ();
// 0x00000131 System.Void TMPro.Examples.TextConsoleSimulator_<RevealWords>d__8::.ctor(System.Int32)
extern void U3CRevealWordsU3Ed__8__ctor_m5D2D48675C51D6CBD649C1AAD44A80CCA291F310 ();
// 0x00000132 System.Void TMPro.Examples.TextConsoleSimulator_<RevealWords>d__8::System.IDisposable.Dispose()
extern void U3CRevealWordsU3Ed__8_System_IDisposable_Dispose_m9F97B9D63E30AF41B31E44C66F31FE6B22DDFD4C ();
// 0x00000133 System.Boolean TMPro.Examples.TextConsoleSimulator_<RevealWords>d__8::MoveNext()
extern void U3CRevealWordsU3Ed__8_MoveNext_m19EB0E15617A1893EEF1916629334CED1D8E9EA1 ();
// 0x00000134 System.Object TMPro.Examples.TextConsoleSimulator_<RevealWords>d__8::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CRevealWordsU3Ed__8_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m98E45A0AFB76FA46A5DA4E92E3FE114E310D8643 ();
// 0x00000135 System.Void TMPro.Examples.TextConsoleSimulator_<RevealWords>d__8::System.Collections.IEnumerator.Reset()
extern void U3CRevealWordsU3Ed__8_System_Collections_IEnumerator_Reset_m09CF6739322B1DB072CB8CFE591DBBC046008E63 ();
// 0x00000136 System.Object TMPro.Examples.TextConsoleSimulator_<RevealWords>d__8::System.Collections.IEnumerator.get_Current()
extern void U3CRevealWordsU3Ed__8_System_Collections_IEnumerator_get_Current_m2083C1001867012CC47AFA8158F00ED15527C603 ();
// 0x00000137 System.Void TMPro.Examples.TextMeshProFloatingText_<DisplayTextMeshProFloatingText>d__12::.ctor(System.Int32)
extern void U3CDisplayTextMeshProFloatingTextU3Ed__12__ctor_m7E5E121E510EFDCCF0D565EBBF607F80836EBB66 ();
// 0x00000138 System.Void TMPro.Examples.TextMeshProFloatingText_<DisplayTextMeshProFloatingText>d__12::System.IDisposable.Dispose()
extern void U3CDisplayTextMeshProFloatingTextU3Ed__12_System_IDisposable_Dispose_mD0C99DF97552E843D1E86CF689372B3759134BB7 ();
// 0x00000139 System.Boolean TMPro.Examples.TextMeshProFloatingText_<DisplayTextMeshProFloatingText>d__12::MoveNext()
extern void U3CDisplayTextMeshProFloatingTextU3Ed__12_MoveNext_mA0FD89A2C5D0867977DAB0896DAB041EDFA64200 ();
// 0x0000013A System.Object TMPro.Examples.TextMeshProFloatingText_<DisplayTextMeshProFloatingText>d__12::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CDisplayTextMeshProFloatingTextU3Ed__12_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m735F43BD7983BCC8E417573886ADC91CDED8F29B ();
// 0x0000013B System.Void TMPro.Examples.TextMeshProFloatingText_<DisplayTextMeshProFloatingText>d__12::System.Collections.IEnumerator.Reset()
extern void U3CDisplayTextMeshProFloatingTextU3Ed__12_System_Collections_IEnumerator_Reset_mBE24EA2EDAFC5FD22D633595174B122D5F84BB02 ();
// 0x0000013C System.Object TMPro.Examples.TextMeshProFloatingText_<DisplayTextMeshProFloatingText>d__12::System.Collections.IEnumerator.get_Current()
extern void U3CDisplayTextMeshProFloatingTextU3Ed__12_System_Collections_IEnumerator_get_Current_m4199EEF69BC21DC6DDC2A0D0323AB70508CB1194 ();
// 0x0000013D System.Void TMPro.Examples.TextMeshProFloatingText_<DisplayTextMeshFloatingText>d__13::.ctor(System.Int32)
extern void U3CDisplayTextMeshFloatingTextU3Ed__13__ctor_m664F9327A457FB4D53F20172479BB74A4B50675A ();
// 0x0000013E System.Void TMPro.Examples.TextMeshProFloatingText_<DisplayTextMeshFloatingText>d__13::System.IDisposable.Dispose()
extern void U3CDisplayTextMeshFloatingTextU3Ed__13_System_IDisposable_Dispose_mA301D3B10770F41C50E25B8785CE78B373BBCE7C ();
// 0x0000013F System.Boolean TMPro.Examples.TextMeshProFloatingText_<DisplayTextMeshFloatingText>d__13::MoveNext()
extern void U3CDisplayTextMeshFloatingTextU3Ed__13_MoveNext_m96E4CEDBAD5AA7AC7C96A481502B002BC711725F ();
// 0x00000140 System.Object TMPro.Examples.TextMeshProFloatingText_<DisplayTextMeshFloatingText>d__13::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CDisplayTextMeshFloatingTextU3Ed__13_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m7609D75AFDAE758DAAE60202465AB3733475352B ();
// 0x00000141 System.Void TMPro.Examples.TextMeshProFloatingText_<DisplayTextMeshFloatingText>d__13::System.Collections.IEnumerator.Reset()
extern void U3CDisplayTextMeshFloatingTextU3Ed__13_System_Collections_IEnumerator_Reset_m6F0C933685FE89DF2DECC34EDD2FE5AD10542579 ();
// 0x00000142 System.Object TMPro.Examples.TextMeshProFloatingText_<DisplayTextMeshFloatingText>d__13::System.Collections.IEnumerator.get_Current()
extern void U3CDisplayTextMeshFloatingTextU3Ed__13_System_Collections_IEnumerator_get_Current_m29F3BB8ADAADB8FD750636C535D2B50292E2DE3B ();
// 0x00000143 System.Void TMPro.Examples.VertexColorCycler_<AnimateVertexColors>d__3::.ctor(System.Int32)
extern void U3CAnimateVertexColorsU3Ed__3__ctor_mD05EA47C6D3F9DC7BE5B4F687A62244E48BC3808 ();
// 0x00000144 System.Void TMPro.Examples.VertexColorCycler_<AnimateVertexColors>d__3::System.IDisposable.Dispose()
extern void U3CAnimateVertexColorsU3Ed__3_System_IDisposable_Dispose_m5E0C78AE94BC2C9BD7818EF0DD43D46ABF8C0172 ();
// 0x00000145 System.Boolean TMPro.Examples.VertexColorCycler_<AnimateVertexColors>d__3::MoveNext()
extern void U3CAnimateVertexColorsU3Ed__3_MoveNext_m8ABBF64D39EB5C5AC87AE0D833B6CBE570444347 ();
// 0x00000146 System.Object TMPro.Examples.VertexColorCycler_<AnimateVertexColors>d__3::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CAnimateVertexColorsU3Ed__3_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m328E88E5192D85CDD2157E26CD15CC0B21149AB6 ();
// 0x00000147 System.Void TMPro.Examples.VertexColorCycler_<AnimateVertexColors>d__3::System.Collections.IEnumerator.Reset()
extern void U3CAnimateVertexColorsU3Ed__3_System_Collections_IEnumerator_Reset_mB49B7C6E42E5B1F488ECA85B1B79AC1D6BBC3022 ();
// 0x00000148 System.Object TMPro.Examples.VertexColorCycler_<AnimateVertexColors>d__3::System.Collections.IEnumerator.get_Current()
extern void U3CAnimateVertexColorsU3Ed__3_System_Collections_IEnumerator_get_Current_m6966F60B8B8F4540B175D0C145D8A73C89CE5429 ();
// 0x00000149 System.Void TMPro.Examples.VertexJitter_<AnimateVertexColors>d__11::.ctor(System.Int32)
extern void U3CAnimateVertexColorsU3Ed__11__ctor_m14F85BFAE5EFFAF0BBD6519F6A65B1EE36FC5F0F ();
// 0x0000014A System.Void TMPro.Examples.VertexJitter_<AnimateVertexColors>d__11::System.IDisposable.Dispose()
extern void U3CAnimateVertexColorsU3Ed__11_System_IDisposable_Dispose_m36A05E300F1E06AE13E2BFF19C18A59F3E73424A ();
// 0x0000014B System.Boolean TMPro.Examples.VertexJitter_<AnimateVertexColors>d__11::MoveNext()
extern void U3CAnimateVertexColorsU3Ed__11_MoveNext_m95629D41B32EBFFE935AA88081C00EB958D17F53 ();
// 0x0000014C System.Object TMPro.Examples.VertexJitter_<AnimateVertexColors>d__11::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CAnimateVertexColorsU3Ed__11_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m994AE653E10219CEB601B88CC22E332FF8AD1F36 ();
// 0x0000014D System.Void TMPro.Examples.VertexJitter_<AnimateVertexColors>d__11::System.Collections.IEnumerator.Reset()
extern void U3CAnimateVertexColorsU3Ed__11_System_Collections_IEnumerator_Reset_mE8D9B5795F095798688B43CF40C04C3FE3F01841 ();
// 0x0000014E System.Object TMPro.Examples.VertexJitter_<AnimateVertexColors>d__11::System.Collections.IEnumerator.get_Current()
extern void U3CAnimateVertexColorsU3Ed__11_System_Collections_IEnumerator_get_Current_m12F2FCDBABCD9F41374064CAD53515D2D039EFD0 ();
// 0x0000014F System.Void TMPro.Examples.VertexShakeA_<AnimateVertexColors>d__11::.ctor(System.Int32)
extern void U3CAnimateVertexColorsU3Ed__11__ctor_m93C153A3293F3E7F9AB47C712F5D8BC9CB0B179D ();
// 0x00000150 System.Void TMPro.Examples.VertexShakeA_<AnimateVertexColors>d__11::System.IDisposable.Dispose()
extern void U3CAnimateVertexColorsU3Ed__11_System_IDisposable_Dispose_m6E2E964131F208551826E353B282FBB9477CB002 ();
// 0x00000151 System.Boolean TMPro.Examples.VertexShakeA_<AnimateVertexColors>d__11::MoveNext()
extern void U3CAnimateVertexColorsU3Ed__11_MoveNext_mD5F89478A4FDEA52E1261CCCF30CC88B0D693407 ();
// 0x00000152 System.Object TMPro.Examples.VertexShakeA_<AnimateVertexColors>d__11::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CAnimateVertexColorsU3Ed__11_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mE6A7BC75B026CFA96FA1C123E6F7E5A5AAFC46E9 ();
// 0x00000153 System.Void TMPro.Examples.VertexShakeA_<AnimateVertexColors>d__11::System.Collections.IEnumerator.Reset()
extern void U3CAnimateVertexColorsU3Ed__11_System_Collections_IEnumerator_Reset_m28679C8DDFAAD809DD115DB68829543159F47FBD ();
// 0x00000154 System.Object TMPro.Examples.VertexShakeA_<AnimateVertexColors>d__11::System.Collections.IEnumerator.get_Current()
extern void U3CAnimateVertexColorsU3Ed__11_System_Collections_IEnumerator_get_Current_m85E44906BDBB53959D8A47AE74B74420179AD3EC ();
// 0x00000155 System.Void TMPro.Examples.VertexShakeB_<AnimateVertexColors>d__10::.ctor(System.Int32)
extern void U3CAnimateVertexColorsU3Ed__10__ctor_m9B592C7897687114428DF0983D5CE52A21051818 ();
// 0x00000156 System.Void TMPro.Examples.VertexShakeB_<AnimateVertexColors>d__10::System.IDisposable.Dispose()
extern void U3CAnimateVertexColorsU3Ed__10_System_IDisposable_Dispose_m24A98FB24DAE578F96B90B3A6D61D18400A731B1 ();
// 0x00000157 System.Boolean TMPro.Examples.VertexShakeB_<AnimateVertexColors>d__10::MoveNext()
extern void U3CAnimateVertexColorsU3Ed__10_MoveNext_m52F01BB7305705B9DE4309E1A05E2725BA06672E ();
// 0x00000158 System.Object TMPro.Examples.VertexShakeB_<AnimateVertexColors>d__10::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CAnimateVertexColorsU3Ed__10_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mB05E3BDEFD461F6516F45D404DBDEC452C646D37 ();
// 0x00000159 System.Void TMPro.Examples.VertexShakeB_<AnimateVertexColors>d__10::System.Collections.IEnumerator.Reset()
extern void U3CAnimateVertexColorsU3Ed__10_System_Collections_IEnumerator_Reset_m72086FED04B8AC40B92836B894D6807AFB51BB38 ();
// 0x0000015A System.Object TMPro.Examples.VertexShakeB_<AnimateVertexColors>d__10::System.Collections.IEnumerator.get_Current()
extern void U3CAnimateVertexColorsU3Ed__10_System_Collections_IEnumerator_get_Current_mA1E44018FA1464D953241F5FA414715C9ADE98CF ();
// 0x0000015B System.Void TMPro.Examples.VertexZoom_<>c__DisplayClass10_0::.ctor()
extern void U3CU3Ec__DisplayClass10_0__ctor_mF154C9990B4AF8DA353F6A8C115C96FB7CB76410 ();
// 0x0000015C System.Int32 TMPro.Examples.VertexZoom_<>c__DisplayClass10_0::<AnimateVertexColors>b__0(System.Int32,System.Int32)
extern void U3CU3Ec__DisplayClass10_0_U3CAnimateVertexColorsU3Eb__0_mDEE1E28BD53D02CB2E40D0C263BBA65C0B5AC66C ();
// 0x0000015D System.Void TMPro.Examples.VertexZoom_<AnimateVertexColors>d__10::.ctor(System.Int32)
extern void U3CAnimateVertexColorsU3Ed__10__ctor_m92C755B17AC00199A759541B62E354765068E7F1 ();
// 0x0000015E System.Void TMPro.Examples.VertexZoom_<AnimateVertexColors>d__10::System.IDisposable.Dispose()
extern void U3CAnimateVertexColorsU3Ed__10_System_IDisposable_Dispose_mBA95580B1808E4EB047CD7F082595E1C5EE930C2 ();
// 0x0000015F System.Boolean TMPro.Examples.VertexZoom_<AnimateVertexColors>d__10::MoveNext()
extern void U3CAnimateVertexColorsU3Ed__10_MoveNext_mA307F1943028D7555032189B48F6289E09D2E220 ();
// 0x00000160 System.Object TMPro.Examples.VertexZoom_<AnimateVertexColors>d__10::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CAnimateVertexColorsU3Ed__10_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m5288CCD0BF91027A0CE3AE12D301F3E5189F0DCE ();
// 0x00000161 System.Void TMPro.Examples.VertexZoom_<AnimateVertexColors>d__10::System.Collections.IEnumerator.Reset()
extern void U3CAnimateVertexColorsU3Ed__10_System_Collections_IEnumerator_Reset_m7C214643A52D954B2755D3477C3D0BFC85DAFF8E ();
// 0x00000162 System.Object TMPro.Examples.VertexZoom_<AnimateVertexColors>d__10::System.Collections.IEnumerator.get_Current()
extern void U3CAnimateVertexColorsU3Ed__10_System_Collections_IEnumerator_get_Current_m666CA82A5C974B5AC09F277AFC97A82D1D1C365E ();
// 0x00000163 System.Void TMPro.Examples.WarpTextExample_<WarpText>d__8::.ctor(System.Int32)
extern void U3CWarpTextU3Ed__8__ctor_m63F411BEA2E513D84AAA701A1EDF0D0322FDE9C4 ();
// 0x00000164 System.Void TMPro.Examples.WarpTextExample_<WarpText>d__8::System.IDisposable.Dispose()
extern void U3CWarpTextU3Ed__8_System_IDisposable_Dispose_m3D9631AF92186316351AFF095E5176423B84E25F ();
// 0x00000165 System.Boolean TMPro.Examples.WarpTextExample_<WarpText>d__8::MoveNext()
extern void U3CWarpTextU3Ed__8_MoveNext_m24ED53830B643858F6068C6908E7C0E044C671A4 ();
// 0x00000166 System.Object TMPro.Examples.WarpTextExample_<WarpText>d__8::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CWarpTextU3Ed__8_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m07B1ABC445F7EADD1DB5F513857F1607C97AAC12 ();
// 0x00000167 System.Void TMPro.Examples.WarpTextExample_<WarpText>d__8::System.Collections.IEnumerator.Reset()
extern void U3CWarpTextU3Ed__8_System_Collections_IEnumerator_Reset_m4C7C46CC80C502CC1AD61D2F9DAF34F09226AF06 ();
// 0x00000168 System.Object TMPro.Examples.WarpTextExample_<WarpText>d__8::System.Collections.IEnumerator.get_Current()
extern void U3CWarpTextU3Ed__8_System_Collections_IEnumerator_get_Current_m86693688EEF5E754D44B448E82D87FAB40D6C8B8 ();
// 0x00000169 System.Void UnityTemplateProjects.SimpleCameraController_CameraState::SetFromTransform(UnityEngine.Transform)
extern void CameraState_SetFromTransform_m6467352ED87301E5F4A76456060A765CAB96AF3E ();
// 0x0000016A System.Void UnityTemplateProjects.SimpleCameraController_CameraState::Translate(UnityEngine.Vector3)
extern void CameraState_Translate_m76BCC104A48EA7F125D5A50D874A2DEEA7967247 ();
// 0x0000016B System.Void UnityTemplateProjects.SimpleCameraController_CameraState::LerpTowards(UnityTemplateProjects.SimpleCameraController_CameraState,System.Single,System.Single)
extern void CameraState_LerpTowards_m883AAF2D3C7F5045B64CAF655FB84EF0FC98F282 ();
// 0x0000016C System.Void UnityTemplateProjects.SimpleCameraController_CameraState::UpdateTransform(UnityEngine.Transform)
extern void CameraState_UpdateTransform_mE3349362276789C1617C01276F7DE533BBA22623 ();
// 0x0000016D System.Void UnityTemplateProjects.SimpleCameraController_CameraState::.ctor()
extern void CameraState__ctor_m4A83DF36C7D280050EA1B101E61B7E345C31A322 ();
static Il2CppMethodPointer s_methodPointers[365] = 
{
	MainMenu_Start_mDF8837F303DD240CE4438A6ABC3D07F7D9B3620E,
	MainMenu_Update_mFAD507C36372E10DEC5939AB521016F0A36D4BBF,
	MainMenu_nextLevel_m126AD0F612D27E950C38BCFC775C9817954F1824,
	MainMenu_quitGame_m4AAE7E4C2F1EE3FA0F7A88130F5D661211FA158A,
	MainMenu__ctor_m63F945D965550BD614DCD2AE7F7489D4F28C5B30,
	NumPadInput_Start_m770DD05782E1443128394BBD97A09D624B815A11,
	NumPadInput_Update_m3C11999B443BD0A297B242A735CB3091A5E84172,
	NumPadInput_add1_m1769E3D44F6915ABD03199BFCB39A7B1E633C8D9,
	NumPadInput_add2_m2673080B55DA2826727DA10617F2E2081775B52F,
	NumPadInput_add3_mBC7BE1EE797934E36BA700CD6A48E96526251F54,
	NumPadInput_add4_mAD5B3E01F1A111604D55B2E5468B45B07BE4083E,
	NumPadInput_add5_m2D9844D15B2CF0A5233E98B06AE8D23DC15C666B,
	NumPadInput_add6_mCB6A7E675D66025087DEC6C6B4B967777EB5E4F1,
	NumPadInput_add7_m97AD41C6B36D0CB2E83E769A07F36E6EB3C70CE1,
	NumPadInput_add8_m40D553A7969807286A55B8417938A84281F0A43B,
	NumPadInput_add9_mB6C36F4947F65F2851C62E7005CF088AABF7145F,
	NumPadInput_add0_mC99A6277C30A2C00AE776E5F9FDF03DD4939798E,
	NumPadInput_Exit_m9E5D56CB6B21D23DECEE02F376C7BF93FB3698A7,
	NumPadInput_Enter_m8F2DC1AD7D8F158B65DDFF4387019FD9694EB3CC,
	NumPadInput__ctor_m81E70D543EFC90A6527FB0E1251E30B8AC44B1B9,
	followPlayer_Start_m57B009531B073D04C015F6EE7B42F1AC5290E2EB,
	followPlayer_Update_mC554D294B28EC73DFE8FD40788CB969EBEAD6E3A,
	followPlayer__ctor_m20D327E97E8A60D7BC77E2E26F2887E8ABA47E0A,
	mouseLook_Start_mCD34D1DE77D44AD36B5828211814A8DC287ABFCC,
	mouseLook_Update_mB74CE81BBB08E50015C3A343FAD0CC74EA96B66D,
	mouseLook__ctor_mAA071B4976040EB8F2C410970F3762E539A6F118,
	playerMovement_Start_m2CCFD2E55DD1946EAA2AE537FECC34CB411A0367,
	playerMovement_Update_m60C2DE2B3C0A9CFD6EA6CBBDE99CA74CBAB7C733,
	playerMovement_enableHintInteract_mE62B2177C62A02D3A18C0FEEA548CED9A1D0A040,
	playerMovement_enableItemInteract_m025019E9433CDB97C189CABB662665A74B0494F2,
	playerMovement_enableNumpadInteract_mD8646B0698146C32453CEA9B45277C452F5C1146,
	playerMovement_disableHintInteract_m29BEF1431784EA44A9D90F54D0420233D5D68468,
	playerMovement_disableItemInteract_mD2FF484C3367EAD46D515D8AD79E5B2402D263B5,
	playerMovement_disableNumpadInteract_m5A3057C6DF4C84FD9CDB99D5FDCA76C4F605D188,
	playerMovement__ctor_mE5A7BD43C0E23AC70BF117434F0AC89D0DF3E108,
	DoorOpen_Start_m1F7E9B7B98007752ECA86CE3F831CCE60B9A94D8,
	DoorOpen_Update_m4F68D3A52A3D0D12B0811709F6BCD8DDD78C7C1F,
	DoorOpen_OpenDoor_m44EC3B72936DD5AD22E73C3506A0516C3761B582,
	DoorOpen__ctor_m0B1CE4F8A078F82062E622AA921F22F675015CB5,
	InteractNumpad_Start_m29864E7F28C2523419E1EB6CE0847D75F231C3B5,
	InteractNumpad_Update_mEF918536C388526C078AAD9FC94808CE8EAC2AD8,
	InteractNumpad_OnTriggerEnter_m9AE5233D580CD72B54A34CB8B9C790AD6B3B545D,
	InteractNumpad_Deactivate_m23C58094158C7277A20E19A34DDFAA8F902AFE45,
	InteractNumpad_Return_mFF049E7E8D404323F6ED214A7120E284DF0BA6F6,
	InteractNumpad_turnOn_m06D70182BEBA7C25983B8DF0C02AAA5BBF758702,
	InteractNumpad__ctor_m45EC8C9E1240CE478C857EB2823D5BB9C6053129,
	InteractibleHint_Start_m6AA6214DC4A979A467D3ACD98A044ED2BA84C1BD,
	InteractibleHint_Update_m321C2762F96D94575F4EEC5D84EA25A1F31B0916,
	InteractibleHint_OnTriggerEnter_mF6E482BD49AFE1B43DA8704FEE7292DA332F4ACD,
	InteractibleHint_OnTriggerExit_mBFEFED90CF5142C6460BA7B1071CC750326A6BA1,
	InteractibleHint_interactText_m959B141436B50FAA92CDBE31BA2E74F622670F67,
	InteractibleHint__ctor_mCDA92B4294141D3C36FB072728532A24D25DD55D,
	InteractibleItem_Start_mA5F84C52952863EF93D3B7C6A1B0D0C85F9A6024,
	InteractibleItem_Update_m92DBB646296893B9AF37376F70A95D12535FD1BF,
	InteractibleItem_OnTriggerEnter_m414553CC5037578D349CC65292832E7524F2CF75,
	InteractibleItem_OnTriggerExit_m1EF38906A3EE6719D35B8AEE1CDCD1802FEB3064,
	InteractibleItem_BecomeActive_mA131543EC94CD29FDE63C23BCEF77CEB4B4F924F,
	InteractibleItem_interactCollect_m83C15082A5E82E2EF808CED5960112677887B30D,
	InteractibleItem__ctor_m982771AA06BF0083EE8222D2ED8DF56E2F567F15,
	PanelControl_Start_mB2A2A55E5527B44BAA46E986EC58723B8050EA00,
	PanelControl_Update_mA715533B8AC6090CD005F8F168E0EFD196124409,
	PanelControl_startFade_mC7A822669B09A1D028FA7CBDD96DA64BD6685D8A,
	PanelControl_startSolidify_m802E606D154466FAFA5A17539489C0A5A0668AD2,
	PanelControl_startSolidify_m067BFA5830EB5ABC9BB1578B8DAE00B6F58813E9,
	PanelControl_fading_m080C750E20CB7B2CA4C4CD0602C3D89057D0C4F7,
	PanelControl_solidifying_mB01CBC88B531C63C44FAAE7E2ADB337243536845,
	PanelControl__ctor_m92F226F124CE2DF289B41070F7ADB29D6DD82B4B,
	SceneChangeFixed_OnTriggerEnter_mCF1D098F9D5559F4961C4CB72755851AE1C49AC2,
	SceneChangeFixed_Start_mF323354487A870B8D919E85D311E159C8E6858EB,
	SceneChangeFixed_Update_m8938E1961155D660EA64EA5EC762483414BA863E,
	SceneChangeFixed__ctor_mF203BF816CA622A7662A7008243992318D2F327E,
	SceneChanger_Start_m6B81BE1B9D274D067D3554052D413F8495A6E5E7,
	SceneChanger_Update_m38073A08CB7CA40DA6F438B51BB023ADE9850D26,
	SceneChanger_OnTriggerEnter_m7A0D73D85E8381280CF57E04388E9C0EF6276900,
	SceneChanger__ctor_m067B4551AA6E9244ADE5C1640964819369FC7B9D,
	scenenum__ctor_m02602B84BE64B90A375F4A170B5C35EE04618A4D,
	colorSet_Start_mB33579D83877F0573E1F13579D43C7E28698F63F,
	colorSet_Update_m14A303B8A05B9A9B009C34D2391D15370BF60BBA,
	colorSet__ctor_mAF3DDD3F9F7B6043AA28CAD58CA37F2124AE39D9,
	cube_Start_m689FB9A00C0F6C83C866C70D4F840AFBB2B8F9EB,
	cube_Update_mF5E92FAC1D93969DC78DC03DEB97C74413B07818,
	cube_runCam_m39C9AF5C83E3F7B67A73485B5AED395DD335424B,
	cube__ctor_m2139AE0873B97EDD0E4B4CAF2220DDE3BFB6F3B5,
	dissapearCube_Start_m92B4C28AFA016816039C3DCD0DB5F85EB4E72FF1,
	dissapearCube_Update_m1DCCFB52C608435C37B16D40D617FAE2C904F9BF,
	dissapearCube__ctor_m58F9235B9DFF921C7188B3F5F0AD1B060CE9250E,
	key_Start_m4E860FADDF15BEF705E805BDC79F842C280E7C5A,
	key_Update_m39D0FE661E8D68AF17BF32F8830A9B9DD909A1C5,
	key__ctor_m59C74657F93DBA250DD38470CBBAF85967C6C38E,
	resultant_Start_mC85EEF61A57F548361310D0F54113633AF16EEB4,
	resultant_Update_m4D07BE564B6A35FA7ECBFF85155DDF3103EDC8E2,
	resultant__ctor_mCCB6A48A460A83FF625DCAE6DCA3165B29302939,
	ChatController_OnEnable_mD13A02B63932BDA275E1A788FD72D86D69B9E440,
	ChatController_OnDisable_mD31D1ED1B2C3C82986BFBD18FA584D45167431F3,
	ChatController_AddToChatOutput_m01CC3E959ACECC222DFD8541231EC1E00C024194,
	ChatController__ctor_mF4343BA56301C6825EB0A71EBF9600525B437BCD,
	EnvMapAnimator_Awake_mAB3C67FA11192EFB31545F42D3D8AAB2A662FEB2,
	EnvMapAnimator_Start_m21098EFD0904DFD43A3CB2FF536E83F1593C2412,
	EnvMapAnimator__ctor_mBA9215F94AB29FBA4D3335AEA6FAB50567509E74,
	Readme__ctor_m23AE6143BDABB863B629ADE701E2998AB8651D4C,
	TMP_DigitValidator_Validate_mD139A23C440A026E47FA8E3AD01AD6FEF7713C3D,
	TMP_DigitValidator__ctor_mF6477F5EB75EC15CD6B81ACD85271F854BABC5D6,
	TMP_PhoneNumberValidator_Validate_mCA5EA200223A9F224F2F4DBD306DAE038C71A35F,
	TMP_PhoneNumberValidator__ctor_mBB38130850945A40631821275F07C19720E0C55E,
	TMP_TextEventHandler_get_onCharacterSelection_mF70DBE3FF43B3D6E64053D37A2FADF802533E1FF,
	TMP_TextEventHandler_set_onCharacterSelection_m237C99FE66E4E16518DAE68FF9CBF1A52E816AD2,
	TMP_TextEventHandler_get_onSpriteSelection_m395603314F8CD073897DCAB5513270C6ADD94BF4,
	TMP_TextEventHandler_set_onSpriteSelection_mAAE4B440E34EE5736D43D6A8A7D3A7CEE0503D69,
	TMP_TextEventHandler_get_onWordSelection_m415F4479934B1739658356B47DF4C2E90496AE2E,
	TMP_TextEventHandler_set_onWordSelection_m6062C0AF2FDD8752DC4A75663EE8E5C128504698,
	TMP_TextEventHandler_get_onLineSelection_m8E724700CC5DF1197B103F87156576A52F62AB2B,
	TMP_TextEventHandler_set_onLineSelection_m1A8E37D2069EF684EF930D4F1ABE764AE17D9A62,
	TMP_TextEventHandler_get_onLinkSelection_m221527467F0606DD3561E0FB0D7678AA8329AD5D,
	TMP_TextEventHandler_set_onLinkSelection_m1376CC9B70177B0C25ACEDF91D5B94BC4B8CF71D,
	TMP_TextEventHandler_Awake_m9A353CC9705A9E824A60C3D2D026A7FD96B41D74,
	TMP_TextEventHandler_LateUpdate_m2F3241223A91F9C50E11B27F67BA2B6D19328B72,
	TMP_TextEventHandler_OnPointerEnter_m1827A9D3F08839023DE71352202FE5F744E150EF,
	TMP_TextEventHandler_OnPointerExit_m788B93D2C3B54BCF09475675B274BCB047D449FB,
	TMP_TextEventHandler_SendOnCharacterSelection_mBC44C107A6FB8C43F7C6629D4A15CA85471A28B2,
	TMP_TextEventHandler_SendOnSpriteSelection_mEF24BCE06B0CE4450B6AE9561EC4B5052DAF00F6,
	TMP_TextEventHandler_SendOnWordSelection_m7C4D266070EE2ADC66BCCFD50EB74FEB4923B77E,
	TMP_TextEventHandler_SendOnLineSelection_mAAF4AF44929D0C9FD73C89E5266028908074AEB1,
	TMP_TextEventHandler_SendOnLinkSelection_m082D12F7D044456D8514E4D31944C6900F8262C0,
	TMP_TextEventHandler__ctor_mEA56AE9489B50CF5E5FC682AA18D1CE9AF8E1F8B,
	Benchmark01_Start_mC0055F208B85783F0B3DB942137439C897552571,
	Benchmark01__ctor_m2FA501D2C572C46A61635E0A3E2FF45EC3A3749C,
	Benchmark01_UGUI_Start_m976ED5172DEAFC628DE7C4C51DF25B1373C7846A,
	Benchmark01_UGUI__ctor_mD92CA5A254960EB149966C2A3243514596C96EAD,
	Benchmark02_Start_m2D028BFC6EFB4C84C1A7A98B87A509B27E75BA06,
	Benchmark02__ctor_m7CA524C53D9E88510EE7987E680F49E8353E4B64,
	Benchmark03_Awake_m8D1A987C39FD4756642011D01F35BDC3B1F99403,
	Benchmark03_Start_m73F65BA012D86A6BE17E82012AE8E2339CA5D550,
	Benchmark03__ctor_m9A5E67EA64AAC56D56C7D269CC9685E78276360A,
	Benchmark04_Start_m22D98FCFC356D5CD7F401DE7EDCDAF7AE0219402,
	Benchmark04__ctor_mDAC3E3BE80C9236562EFB6E74DEBE67D8713101D,
	CameraController_Awake_m581B79998DB6946746CBF7380AFCC7F2B75D99F7,
	CameraController_Start_mA9D72DB0BB6E4F72192DA91BC9F8918A9C61B676,
	CameraController_LateUpdate_mDC862C8119AB0B4807245CC3482F027842EAB425,
	CameraController_GetPlayerInput_m198C209AC84EF7A2437ADB2B67F6B78D12AB9216,
	CameraController__ctor_m2108A608ABD8EA7FD2B47EE40C07F4117BB7607E,
	ObjectSpin_Awake_mDA26D26457D277CC2D9042F3BD623D48849440C4,
	ObjectSpin_Update_mC50AAC1AF75B07CD6753EA3224C369E43001791B,
	ObjectSpin__ctor_m2832B9D713355ECF861642D115F86AA64A6F119E,
	ShaderPropAnimator_Awake_m8E01638EBFE80CC0B9E4A97AB809B91E3C6956BE,
	ShaderPropAnimator_Start_m24F4FADC328B0C76264DE24663CFA914EA94D1FD,
	ShaderPropAnimator_AnimateProperties_mC45F318132D23804CBF73EA2445EF7589C2333E9,
	ShaderPropAnimator__ctor_mC3894CE97A12F50FB225CA8F6F05A7B3CA4B0623,
	SimpleScript_Start_m22A3AE8E48128DF849EE2957F4EF881A433CA8CB,
	SimpleScript_Update_m742F828A2245E8CC29BC045A999C5E527931DFF1,
	SimpleScript__ctor_mA2284F621031B4D494AC06B687AF43D2D1D89BD7,
	SkewTextExample_Awake_m51C217E0CB26C2E627BA01599147F69B893EF189,
	SkewTextExample_Start_m6A9CEFA12DB252E297E41E256698DD4E90809F6A,
	SkewTextExample_CopyAnimationCurve_m3CE7B666BEF4CFFE9EB110C8D57D9A5F6385720B,
	SkewTextExample_WarpText_m4A69C47EA665D49482B930F924E49C8E70FAC225,
	SkewTextExample__ctor_m11DC90EB1A059F4201457E33C4422A7BDA90F099,
	TMP_ExampleScript_01_Awake_m9CE8A9F929B99B2318A6F8598EE20E1D4E842ECD,
	TMP_ExampleScript_01_Update_m8F48CBCC48D4CD26F731BA82ECBAC9DC0392AE0D,
	TMP_ExampleScript_01__ctor_m9F5CE74EDA110F7539B4081CF3EE6B9FCF40D4A7,
	TMP_FrameRateCounter_Awake_m906CC32CE5FE551DF29928581FFF7DE589C501F2,
	TMP_FrameRateCounter_Start_m614FA9DE53ECB1CF4C6AF6BBC58CE35CA904EB32,
	TMP_FrameRateCounter_Update_m16AB65EF6AB38F237F5A6D2D412AB7E5BF7B1349,
	TMP_FrameRateCounter_Set_FrameCounter_Position_m537A709F25C3AA752437A025BEE741BD2F71320E,
	TMP_FrameRateCounter__ctor_mD86AC3A8D918D14200BF80A354E0E43DC5A565A2,
	TMP_TextEventCheck_OnEnable_m22D9B03F3E1269B8B104E76DA083ED105029258A,
	TMP_TextEventCheck_OnDisable_m42813B343A1FDD155C6BFBFCB514E084FB528DA0,
	TMP_TextEventCheck_OnCharacterSelection_mC6992B7B1B6A441DEC5315185E3CE022BB567D61,
	TMP_TextEventCheck_OnSpriteSelection_mEC541297C2228C26AB54F825705F0476D45F877A,
	TMP_TextEventCheck_OnWordSelection_mA1170F805C77CC89B818D8FBEE533846AF66509C,
	TMP_TextEventCheck_OnLineSelection_mB871339347DCB016E019F509A00BDE9A58105822,
	TMP_TextEventCheck_OnLinkSelection_m44A79DDBDF03F254BAFB97BE3E42845B769136C5,
	TMP_TextEventCheck__ctor_mA67343988C9E9B71C981A9FFAD620C4A9A6AA267,
	TMP_TextInfoDebugTool__ctor_m1EA6A5E31F88A1C7E20167A3BCCE427E9E828116,
	TMP_TextSelector_A_Awake_m82972EF3AF67EAAFD94A5EE3EA852CE15BE37FC1,
	TMP_TextSelector_A_LateUpdate_m40594D716F53E6E5BC0ECD2FFE8ECA44FAA5C8E4,
	TMP_TextSelector_A_OnPointerEnter_m8462C2DC4F71BDE295BE446B213B73F78442E264,
	TMP_TextSelector_A_OnPointerExit_m3AC7467ECE689A58590DA325F8B300B08C1E1B5D,
	TMP_TextSelector_A__ctor_m081D44F31AA16E345F914869A07BD47D118707DF,
	TMP_TextSelector_B_Awake_m217B6E2FC4029A304908EE9DC1E4AA2885CBF8A3,
	TMP_TextSelector_B_OnEnable_m24A7CCA0D93F17AC1A12A340277C706B5C2F9BAB,
	TMP_TextSelector_B_OnDisable_m6088452529A70A6684BD8936872B71451779A2F4,
	TMP_TextSelector_B_ON_TEXT_CHANGED_m79EEE4DF7792F553F5DEDCF0094DAC6F2A58137A,
	TMP_TextSelector_B_LateUpdate_m745577078D86EF6C23B914BD03EA1A1D169B9B7B,
	TMP_TextSelector_B_OnPointerEnter_mF6C09A2C64F5D2619014ADD50039358FAD24DB3E,
	TMP_TextSelector_B_OnPointerExit_mB0AAA8D034FC575EB3BCF7B0D4514BD110178AD3,
	TMP_TextSelector_B_OnPointerClick_m13B20506F762769F099DE10B3CCA2DF194192B42,
	TMP_TextSelector_B_OnPointerUp_mD53FD60E0C5930231FB16BDEA37165FF46D85F6E,
	TMP_TextSelector_B_RestoreCachedVertexAttributes_m1D03D0E14D6054D292334C19030256B666ACDA0E,
	TMP_TextSelector_B__ctor_m494C501CF565B1ED7C8CB2951EB6FB4F8505637F,
	TMP_UiFrameRateCounter_Awake_m255A7821E5BA4A7A75B9276E07BC9EA7331B5AA6,
	TMP_UiFrameRateCounter_Start_mA4A02EB5C853A44F251F43F0AD5967AE914E2B0F,
	TMP_UiFrameRateCounter_Update_m04555F8DF147C553FA2D59E33E744901D811B615,
	TMP_UiFrameRateCounter_Set_FrameCounter_Position_mDF0FDFBCD11955E0E1D1C9E961B6AD0690C669ED,
	TMP_UiFrameRateCounter__ctor_m99ACA1D2410917C5837321FC5AC84EAED676D4CC,
	TMPro_InstructionOverlay_Awake_m639E300B56757BDB94766447365E1C94B5B83ACD,
	TMPro_InstructionOverlay_Set_FrameCounter_Position_m74B8F0AE15DA6C9968C482981EBCF5CC9DB1F43D,
	TMPro_InstructionOverlay__ctor_m570C4B4CB3126622D6DFF71158336313C45C717A,
	TeleType_Awake_m5F758974DA88ED8187E71A5100D2D9E47985E359,
	TeleType_Start_mC32B726B6202883E12E1A62A52E50092E7E9D9F0,
	TeleType__ctor_m6CDFDC88D47FE66021C133974C8CB0E16B08A00E,
	TextConsoleSimulator_Awake_m4F61F06DFE11CFAF9B064CCA5B2D6423D5CFC302,
	TextConsoleSimulator_Start_m572903C9070A8AD276D2CB14DF7659AE551C75B3,
	TextConsoleSimulator_OnEnable_m1A36B043E4EDD945C93DFC49F7FAFB7034728593,
	TextConsoleSimulator_OnDisable_m6F9BE1975CB15EE559D3B617E8972C8812B41325,
	TextConsoleSimulator_ON_TEXT_CHANGED_m73C6B3DAA27778B666B9B3B75C9D4641FC1BEC8A,
	TextConsoleSimulator_RevealCharacters_mC24F1D67B99F0AFE7535143BB60C530C8E8735F0,
	TextConsoleSimulator_RevealWords_m68CAA9BDC1DF3454ECB7C5496A5A2020F84027B8,
	TextConsoleSimulator__ctor_m4DB9B9E3836D192AA7F42B7EBDC31883E39610E9,
	TextMeshProFloatingText_Awake_mD99CC6A70945373DA699327F5A0D0C4516A7D02A,
	TextMeshProFloatingText_Start_m3286BB7639F6042AD4437D41BF4633326C4290BE,
	TextMeshProFloatingText_DisplayTextMeshProFloatingText_m61ABFBAA95ED83A248FBCC3F5823907824434D34,
	TextMeshProFloatingText_DisplayTextMeshFloatingText_m65A61DF0BA640F2787DD87E93B8FD9DEC14AACB4,
	TextMeshProFloatingText__ctor_m11DBC535BA8001B48A06F61515C0787C3A86611F,
	TextMeshSpawner_Awake_mB3C405B4856E9B437E13E4BD85DAE73FFF1F6561,
	TextMeshSpawner_Start_m436D4CD2A82C0F95B8D942DF4CCFCE09792EDF0F,
	TextMeshSpawner__ctor_mDB693DABF1C3BA92B7A3A4E1460F28E3FAFB444D,
	VertexColorCycler_Awake_mAEEAA831C084B447DFD0C91A5FA606CB26D3E22A,
	VertexColorCycler_Start_mF01B64B3E5FE5B648DE2EED031962D9183C2D238,
	VertexColorCycler_AnimateVertexColors_m9CDB87631C324FB89FA7D52F5BC910146F3DDEB7,
	VertexColorCycler__ctor_m9B68D69B87E07DC0154344E5276EFC5B11205718,
	VertexJitter_Awake_m9699A62E72D3A262EDFDF7AC63ABD33E53F179B6,
	VertexJitter_OnEnable_m1B592E7AC81C7F17D0A59325EBDE71E067178E8A,
	VertexJitter_OnDisable_m5567B541D1602AD54B0F437D4710BCD1951FE2C5,
	VertexJitter_Start_mB698E212B8C3B7C66C71C88F4761A4F33FCE4683,
	VertexJitter_ON_TEXT_CHANGED_m09CFD4E872042E7377BEC8B95D34F22F62ABC45B,
	VertexJitter_AnimateVertexColors_m1CCF60CA14B2FF530950D366FF078281ADC48FF4,
	VertexJitter__ctor_mC19C148659C8C97357DB56F36E14914133DA93CF,
	VertexShakeA_Awake_mD2ABEB338822E0DBCFDEC1DB46EC20BB2C44A8C2,
	VertexShakeA_OnEnable_m60947EACA10408B6EAD2EC7AC77B4E54E2666DD8,
	VertexShakeA_OnDisable_mF5AF9069E523C0DF610EF3BE2017E73A4609E3CC,
	VertexShakeA_Start_m96D17C13A279F9B442588F6448672BCF07E4A409,
	VertexShakeA_ON_TEXT_CHANGED_mE761EE13D2F9573841EFA5DEE82E545545280BFA,
	VertexShakeA_AnimateVertexColors_mC97FED540BDE59254AB30C5E6BCF1F53B766945F,
	VertexShakeA__ctor_mD84B9A0167705D5D3C8CA024D479DC7B5362E67B,
	VertexShakeB_Awake_mA59F3CA197B3A474F4D795E2B3F182179FF633CF,
	VertexShakeB_OnEnable_m8D4DD5CA81E5B0C02937D43C1782533D54F34B3F,
	VertexShakeB_OnDisable_m4473873008D4A843A26F0D2353FC36ABE74CEED2,
	VertexShakeB_Start_m24BEF670ABD1CCC864FAFE04750FEB83D916D0DF,
	VertexShakeB_ON_TEXT_CHANGED_mCC864EE9569AF68F53F6EAEB2CE8077CFEAF9E53,
	VertexShakeB_AnimateVertexColors_mAF3B23F4DD98AC3E641700B994B2994C14F0E12C,
	VertexShakeB__ctor_mDCAEC737A20F161914DD12A2FCBAB6AB7C64FEF2,
	VertexZoom_Awake_m5F98434E568929859E250743BA214C0782D17F2B,
	VertexZoom_OnEnable_m01E35B4259BA0B13EC5DA18A11535C2EC6344123,
	VertexZoom_OnDisable_mACD450919605863EC4C36DA360898BAEBBF3DDDB,
	VertexZoom_Start_m6910FF4AC88466E3B7DB867AD553429F1745320D,
	VertexZoom_ON_TEXT_CHANGED_mBFB58FE53145750AD747B38D9D1E7E00F8DBF9A0,
	VertexZoom_AnimateVertexColors_m328088EC0F893B3E60BB072F77ADF939B8566E4D,
	VertexZoom__ctor_m67833553C2739616BF059C661F92A032885510B2,
	WarpTextExample_Awake_m9643904751E2DF0A7DF536847AEA1A2B0774DD20,
	WarpTextExample_Start_mDF931C271901519BF21FD356F706FA8CDE236406,
	WarpTextExample_CopyAnimationCurve_m2C738EA265E2B35868110EE1D8FCBD4F1D61C038,
	WarpTextExample_WarpText_mAAAB1687869E0121C858C65BDB2D294D55CFB67A,
	WarpTextExample__ctor_mC3EAA1AE81FB3DA4B25F20E557EC6627A06DCB31,
	SimpleCameraController_OnEnable_mE3D6E47455F101F2DEEBC2A58D09A97CF38E80B8,
	SimpleCameraController_GetInputTranslationDirection_m73C99DB69CEB467834BBA00A62415D1CEEF0CB47,
	SimpleCameraController_Update_mBCD24408A4A2C4053F2F98DB808BD6DE88CA998F,
	SimpleCameraController__ctor_m8DE12FC1A6C31D2D60ED78F0B574CE3F864F546E,
	U3CStartU3Ed__4__ctor_m004DF17C34E6A9C76325BD4C65E0F328AD4B37E0,
	U3CStartU3Ed__4_System_IDisposable_Dispose_mE7E20C5789828A8FDE263BD5ACC2D02982334B46,
	U3CStartU3Ed__4_MoveNext_mB3F55ABCABBA6717942BDC85935FDE439D09E226,
	U3CStartU3Ed__4_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mF976D094846BDC403335C76F41CAC26D53C8F1D2,
	U3CStartU3Ed__4_System_Collections_IEnumerator_Reset_m9368B3951732B0D18993DA1B889346A775F252CE,
	U3CStartU3Ed__4_System_Collections_IEnumerator_get_Current_m495592283D84E6B446F7B9B7405F250D9687DEFB,
	Section__ctor_mE73C1D6AE5454B5A67AAB04CAA5144A5CA0B0D96,
	CharacterSelectionEvent__ctor_m036DA7F340B0839696EB50045AB186BD1046BE85,
	SpriteSelectionEvent__ctor_m0BC042938C4EBBB77FFAD68C1ACD74FC1C3C1052,
	WordSelectionEvent__ctor_m1C01733FD9860337084DFE63607ECE0EF8A450EA,
	LineSelectionEvent__ctor_m1C3A0C84C5C0FEA6C33FA9ED99756A85363C9EF2,
	LinkSelectionEvent__ctor_mC7034F51586C51D1DE381F6222816DC1542AFF3A,
	U3CStartU3Ed__10__ctor_m139DF863E59AD287A6C14228BB59D56E7FD2E578,
	U3CStartU3Ed__10_System_IDisposable_Dispose_mBBFAE2F68813477259A0B665B4E81833C03C746B,
	U3CStartU3Ed__10_MoveNext_m8D27A150B4BC045DD5A1ACB2FABBB7F7F318A015,
	U3CStartU3Ed__10_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m9C55687F407BA372889D6A533FB817E1EA81C165,
	U3CStartU3Ed__10_System_Collections_IEnumerator_Reset_mE725DFFE744FAEDABF70579D04BBEB17A6CFF692,
	U3CStartU3Ed__10_System_Collections_IEnumerator_get_Current_mD8EEDE3D2E1E9838472D20AE93DD750D1EE39AF8,
	U3CStartU3Ed__10__ctor_mECD4DB9695B4D04CEF08DF193DAFA21412DA40EF,
	U3CStartU3Ed__10_System_IDisposable_Dispose_m6773C67C5C6E7E52F8C8545181173A58A6B7D939,
	U3CStartU3Ed__10_MoveNext_mB823F98B1B0907B6959EAEE4D1EBE0AA35795EA3,
	U3CStartU3Ed__10_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mF100CFC13DED969B3BBE2007B3F863DCE919D978,
	U3CStartU3Ed__10_System_Collections_IEnumerator_Reset_mDE1D3A30ECA00E3CA2218A582F2C87EEE082E2DB,
	U3CStartU3Ed__10_System_Collections_IEnumerator_get_Current_m13710692FCBB7BB736B1F6446778124064802C83,
	U3CAnimatePropertiesU3Ed__6__ctor_mB4DA3EEEFC5ECB8376EF29EAC034162B575961B8,
	U3CAnimatePropertiesU3Ed__6_System_IDisposable_Dispose_mC6A68A27A902E234429E3706D6DB432BEA04A384,
	U3CAnimatePropertiesU3Ed__6_MoveNext_mDE142F6B3AAB5916834A6820A5E7B13A7B71E822,
	U3CAnimatePropertiesU3Ed__6_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m9F4D59DDC372B977CD7297AA5F0C83D4FFBBA830,
	U3CAnimatePropertiesU3Ed__6_System_Collections_IEnumerator_Reset_mAC1E960F7FFCF032EE668635835954377D1469F6,
	U3CAnimatePropertiesU3Ed__6_System_Collections_IEnumerator_get_Current_m96B6B8A0D715268DB789F3D4C60FC6DEC9E1F6E6,
	U3CWarpTextU3Ed__7__ctor_m07871FDF578BC130082658B43FB4322C15F0909E,
	U3CWarpTextU3Ed__7_System_IDisposable_Dispose_m3C8BC1501397E256464ADD27A32486CDE63C2BE2,
	U3CWarpTextU3Ed__7_MoveNext_m11D4701B069FCFC106319CBDCA56244EFA4C795F,
	U3CWarpTextU3Ed__7_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m995FCE4A3B9B270605168D01EF7439A437864C06,
	U3CWarpTextU3Ed__7_System_Collections_IEnumerator_Reset_m9970CA113E1A293472987C004B42771993CAA05C,
	U3CWarpTextU3Ed__7_System_Collections_IEnumerator_get_Current_m398E9D0D09F26D5C3268EB41936ED92240474910,
	U3CStartU3Ed__4__ctor_mFB2D6F55665AAA83D38C58F58FA9DD0F5CE51351,
	U3CStartU3Ed__4_System_IDisposable_Dispose_m72D91E3700B8E1F2053A7620793F97E01C1A2E3A,
	U3CStartU3Ed__4_MoveNext_m2839A135AFB4518430283897981AF4C91ABDBC6A,
	U3CStartU3Ed__4_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mB3E80ED07333F946FC221C16A77997DF51A80F87,
	U3CStartU3Ed__4_System_Collections_IEnumerator_Reset_mAC8E620F4FCE24A409840017FB003AA1048497EF,
	U3CStartU3Ed__4_System_Collections_IEnumerator_get_Current_mD6DFD0886CCA250CB95B2828DEEEEE5EA6DC303A,
	U3CRevealCharactersU3Ed__7__ctor_mAF579198F26F3FD002CB7F4919CCB513E2B770E1,
	U3CRevealCharactersU3Ed__7_System_IDisposable_Dispose_m2B3AB12689498DE28F90CF5DA3D40AA6C31B928E,
	U3CRevealCharactersU3Ed__7_MoveNext_m16C2594A51B9D102B30646C47111F3476FFBF311,
	U3CRevealCharactersU3Ed__7_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m8B5325041D4E4A3F3D5575373F25A93752D9E514,
	U3CRevealCharactersU3Ed__7_System_Collections_IEnumerator_Reset_m321E1A1FD7DE7840F8433BF739D3E889FB3E9C7C,
	U3CRevealCharactersU3Ed__7_System_Collections_IEnumerator_get_Current_m9CF6271A74900FFA5BD4027E84D63C164C1650BC,
	U3CRevealWordsU3Ed__8__ctor_m5D2D48675C51D6CBD649C1AAD44A80CCA291F310,
	U3CRevealWordsU3Ed__8_System_IDisposable_Dispose_m9F97B9D63E30AF41B31E44C66F31FE6B22DDFD4C,
	U3CRevealWordsU3Ed__8_MoveNext_m19EB0E15617A1893EEF1916629334CED1D8E9EA1,
	U3CRevealWordsU3Ed__8_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m98E45A0AFB76FA46A5DA4E92E3FE114E310D8643,
	U3CRevealWordsU3Ed__8_System_Collections_IEnumerator_Reset_m09CF6739322B1DB072CB8CFE591DBBC046008E63,
	U3CRevealWordsU3Ed__8_System_Collections_IEnumerator_get_Current_m2083C1001867012CC47AFA8158F00ED15527C603,
	U3CDisplayTextMeshProFloatingTextU3Ed__12__ctor_m7E5E121E510EFDCCF0D565EBBF607F80836EBB66,
	U3CDisplayTextMeshProFloatingTextU3Ed__12_System_IDisposable_Dispose_mD0C99DF97552E843D1E86CF689372B3759134BB7,
	U3CDisplayTextMeshProFloatingTextU3Ed__12_MoveNext_mA0FD89A2C5D0867977DAB0896DAB041EDFA64200,
	U3CDisplayTextMeshProFloatingTextU3Ed__12_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m735F43BD7983BCC8E417573886ADC91CDED8F29B,
	U3CDisplayTextMeshProFloatingTextU3Ed__12_System_Collections_IEnumerator_Reset_mBE24EA2EDAFC5FD22D633595174B122D5F84BB02,
	U3CDisplayTextMeshProFloatingTextU3Ed__12_System_Collections_IEnumerator_get_Current_m4199EEF69BC21DC6DDC2A0D0323AB70508CB1194,
	U3CDisplayTextMeshFloatingTextU3Ed__13__ctor_m664F9327A457FB4D53F20172479BB74A4B50675A,
	U3CDisplayTextMeshFloatingTextU3Ed__13_System_IDisposable_Dispose_mA301D3B10770F41C50E25B8785CE78B373BBCE7C,
	U3CDisplayTextMeshFloatingTextU3Ed__13_MoveNext_m96E4CEDBAD5AA7AC7C96A481502B002BC711725F,
	U3CDisplayTextMeshFloatingTextU3Ed__13_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m7609D75AFDAE758DAAE60202465AB3733475352B,
	U3CDisplayTextMeshFloatingTextU3Ed__13_System_Collections_IEnumerator_Reset_m6F0C933685FE89DF2DECC34EDD2FE5AD10542579,
	U3CDisplayTextMeshFloatingTextU3Ed__13_System_Collections_IEnumerator_get_Current_m29F3BB8ADAADB8FD750636C535D2B50292E2DE3B,
	U3CAnimateVertexColorsU3Ed__3__ctor_mD05EA47C6D3F9DC7BE5B4F687A62244E48BC3808,
	U3CAnimateVertexColorsU3Ed__3_System_IDisposable_Dispose_m5E0C78AE94BC2C9BD7818EF0DD43D46ABF8C0172,
	U3CAnimateVertexColorsU3Ed__3_MoveNext_m8ABBF64D39EB5C5AC87AE0D833B6CBE570444347,
	U3CAnimateVertexColorsU3Ed__3_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m328E88E5192D85CDD2157E26CD15CC0B21149AB6,
	U3CAnimateVertexColorsU3Ed__3_System_Collections_IEnumerator_Reset_mB49B7C6E42E5B1F488ECA85B1B79AC1D6BBC3022,
	U3CAnimateVertexColorsU3Ed__3_System_Collections_IEnumerator_get_Current_m6966F60B8B8F4540B175D0C145D8A73C89CE5429,
	U3CAnimateVertexColorsU3Ed__11__ctor_m14F85BFAE5EFFAF0BBD6519F6A65B1EE36FC5F0F,
	U3CAnimateVertexColorsU3Ed__11_System_IDisposable_Dispose_m36A05E300F1E06AE13E2BFF19C18A59F3E73424A,
	U3CAnimateVertexColorsU3Ed__11_MoveNext_m95629D41B32EBFFE935AA88081C00EB958D17F53,
	U3CAnimateVertexColorsU3Ed__11_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m994AE653E10219CEB601B88CC22E332FF8AD1F36,
	U3CAnimateVertexColorsU3Ed__11_System_Collections_IEnumerator_Reset_mE8D9B5795F095798688B43CF40C04C3FE3F01841,
	U3CAnimateVertexColorsU3Ed__11_System_Collections_IEnumerator_get_Current_m12F2FCDBABCD9F41374064CAD53515D2D039EFD0,
	U3CAnimateVertexColorsU3Ed__11__ctor_m93C153A3293F3E7F9AB47C712F5D8BC9CB0B179D,
	U3CAnimateVertexColorsU3Ed__11_System_IDisposable_Dispose_m6E2E964131F208551826E353B282FBB9477CB002,
	U3CAnimateVertexColorsU3Ed__11_MoveNext_mD5F89478A4FDEA52E1261CCCF30CC88B0D693407,
	U3CAnimateVertexColorsU3Ed__11_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mE6A7BC75B026CFA96FA1C123E6F7E5A5AAFC46E9,
	U3CAnimateVertexColorsU3Ed__11_System_Collections_IEnumerator_Reset_m28679C8DDFAAD809DD115DB68829543159F47FBD,
	U3CAnimateVertexColorsU3Ed__11_System_Collections_IEnumerator_get_Current_m85E44906BDBB53959D8A47AE74B74420179AD3EC,
	U3CAnimateVertexColorsU3Ed__10__ctor_m9B592C7897687114428DF0983D5CE52A21051818,
	U3CAnimateVertexColorsU3Ed__10_System_IDisposable_Dispose_m24A98FB24DAE578F96B90B3A6D61D18400A731B1,
	U3CAnimateVertexColorsU3Ed__10_MoveNext_m52F01BB7305705B9DE4309E1A05E2725BA06672E,
	U3CAnimateVertexColorsU3Ed__10_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mB05E3BDEFD461F6516F45D404DBDEC452C646D37,
	U3CAnimateVertexColorsU3Ed__10_System_Collections_IEnumerator_Reset_m72086FED04B8AC40B92836B894D6807AFB51BB38,
	U3CAnimateVertexColorsU3Ed__10_System_Collections_IEnumerator_get_Current_mA1E44018FA1464D953241F5FA414715C9ADE98CF,
	U3CU3Ec__DisplayClass10_0__ctor_mF154C9990B4AF8DA353F6A8C115C96FB7CB76410,
	U3CU3Ec__DisplayClass10_0_U3CAnimateVertexColorsU3Eb__0_mDEE1E28BD53D02CB2E40D0C263BBA65C0B5AC66C,
	U3CAnimateVertexColorsU3Ed__10__ctor_m92C755B17AC00199A759541B62E354765068E7F1,
	U3CAnimateVertexColorsU3Ed__10_System_IDisposable_Dispose_mBA95580B1808E4EB047CD7F082595E1C5EE930C2,
	U3CAnimateVertexColorsU3Ed__10_MoveNext_mA307F1943028D7555032189B48F6289E09D2E220,
	U3CAnimateVertexColorsU3Ed__10_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m5288CCD0BF91027A0CE3AE12D301F3E5189F0DCE,
	U3CAnimateVertexColorsU3Ed__10_System_Collections_IEnumerator_Reset_m7C214643A52D954B2755D3477C3D0BFC85DAFF8E,
	U3CAnimateVertexColorsU3Ed__10_System_Collections_IEnumerator_get_Current_m666CA82A5C974B5AC09F277AFC97A82D1D1C365E,
	U3CWarpTextU3Ed__8__ctor_m63F411BEA2E513D84AAA701A1EDF0D0322FDE9C4,
	U3CWarpTextU3Ed__8_System_IDisposable_Dispose_m3D9631AF92186316351AFF095E5176423B84E25F,
	U3CWarpTextU3Ed__8_MoveNext_m24ED53830B643858F6068C6908E7C0E044C671A4,
	U3CWarpTextU3Ed__8_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m07B1ABC445F7EADD1DB5F513857F1607C97AAC12,
	U3CWarpTextU3Ed__8_System_Collections_IEnumerator_Reset_m4C7C46CC80C502CC1AD61D2F9DAF34F09226AF06,
	U3CWarpTextU3Ed__8_System_Collections_IEnumerator_get_Current_m86693688EEF5E754D44B448E82D87FAB40D6C8B8,
	CameraState_SetFromTransform_m6467352ED87301E5F4A76456060A765CAB96AF3E,
	CameraState_Translate_m76BCC104A48EA7F125D5A50D874A2DEEA7967247,
	CameraState_LerpTowards_m883AAF2D3C7F5045B64CAF655FB84EF0FC98F282,
	CameraState_UpdateTransform_mE3349362276789C1617C01276F7DE533BBA22623,
	CameraState__ctor_m4A83DF36C7D280050EA1B101E61B7E345C31A322,
};
static const int32_t s_InvokerIndices[365] = 
{
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	26,
	26,
	26,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	26,
	23,
	23,
	23,
	23,
	23,
	23,
	26,
	26,
	23,
	23,
	23,
	23,
	26,
	26,
	23,
	23,
	23,
	23,
	23,
	23,
	32,
	23,
	23,
	23,
	23,
	26,
	23,
	23,
	23,
	23,
	23,
	26,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	290,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	26,
	23,
	23,
	14,
	23,
	23,
	1619,
	23,
	1619,
	23,
	14,
	26,
	14,
	26,
	14,
	26,
	14,
	26,
	14,
	26,
	23,
	23,
	26,
	26,
	447,
	447,
	35,
	35,
	600,
	23,
	14,
	23,
	14,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	14,
	23,
	23,
	23,
	23,
	23,
	23,
	28,
	14,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	32,
	23,
	23,
	23,
	447,
	447,
	35,
	35,
	600,
	23,
	23,
	23,
	23,
	26,
	26,
	23,
	23,
	23,
	23,
	26,
	23,
	26,
	26,
	26,
	26,
	32,
	23,
	23,
	23,
	23,
	32,
	23,
	23,
	32,
	23,
	23,
	14,
	23,
	23,
	23,
	23,
	23,
	26,
	28,
	28,
	23,
	23,
	23,
	14,
	14,
	23,
	23,
	23,
	23,
	23,
	23,
	14,
	23,
	23,
	23,
	23,
	23,
	26,
	14,
	23,
	23,
	23,
	23,
	23,
	26,
	14,
	23,
	23,
	23,
	23,
	23,
	26,
	14,
	23,
	23,
	23,
	23,
	23,
	26,
	14,
	23,
	23,
	23,
	28,
	14,
	23,
	23,
	1107,
	23,
	23,
	32,
	23,
	114,
	14,
	23,
	14,
	23,
	23,
	23,
	23,
	23,
	23,
	32,
	23,
	114,
	14,
	23,
	14,
	32,
	23,
	114,
	14,
	23,
	14,
	32,
	23,
	114,
	14,
	23,
	14,
	32,
	23,
	114,
	14,
	23,
	14,
	32,
	23,
	114,
	14,
	23,
	14,
	32,
	23,
	114,
	14,
	23,
	14,
	32,
	23,
	114,
	14,
	23,
	14,
	32,
	23,
	114,
	14,
	23,
	14,
	32,
	23,
	114,
	14,
	23,
	14,
	32,
	23,
	114,
	14,
	23,
	14,
	32,
	23,
	114,
	14,
	23,
	14,
	32,
	23,
	114,
	14,
	23,
	14,
	32,
	23,
	114,
	14,
	23,
	14,
	23,
	56,
	32,
	23,
	114,
	14,
	23,
	14,
	32,
	23,
	114,
	14,
	23,
	14,
	26,
	1108,
	1241,
	26,
	23,
};
extern const Il2CppCodeGenModule g_AssemblyU2DCSharpCodeGenModule;
const Il2CppCodeGenModule g_AssemblyU2DCSharpCodeGenModule = 
{
	"Assembly-CSharp.dll",
	365,
	s_methodPointers,
	s_InvokerIndices,
	0,
	NULL,
	0,
	NULL,
	0,
	NULL,
	NULL,
};
