﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif



#include "codegen/il2cpp-codegen-metadata.h"





IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END




// 0x00000001 System.Void UnityEngine.TextCore.FaceInfo::set_familyName(System.String)
extern void FaceInfo_set_familyName_m070B9D53BD86AF04CD44A193236472B863B2A5AD_AdjustorThunk ();
// 0x00000002 System.Void UnityEngine.TextCore.FaceInfo::set_styleName(System.String)
extern void FaceInfo_set_styleName_m178E36C8E91C5F733CC14C8F1C72D9261DF75689_AdjustorThunk ();
// 0x00000003 System.Int32 UnityEngine.TextCore.FaceInfo::get_pointSize()
extern void FaceInfo_get_pointSize_m7FF87189B44B164920FDFBC1AF255255F310B5FF_AdjustorThunk ();
// 0x00000004 System.Void UnityEngine.TextCore.FaceInfo::set_pointSize(System.Int32)
extern void FaceInfo_set_pointSize_m78055606128C35E03B858125ACE7D433EB282949_AdjustorThunk ();
// 0x00000005 System.Single UnityEngine.TextCore.FaceInfo::get_scale()
extern void FaceInfo_get_scale_mF90743435232CC99211482A602E0E8FC85F177F0_AdjustorThunk ();
// 0x00000006 System.Void UnityEngine.TextCore.FaceInfo::set_scale(System.Single)
extern void FaceInfo_set_scale_m785FEBD05216CE8D6A125CFBEFE0D107ACFA7267_AdjustorThunk ();
// 0x00000007 System.Single UnityEngine.TextCore.FaceInfo::get_lineHeight()
extern void FaceInfo_get_lineHeight_m524B1B20AEED2B8A3E9BEA9E2CD1ECBCF0C39E61_AdjustorThunk ();
// 0x00000008 System.Void UnityEngine.TextCore.FaceInfo::set_lineHeight(System.Single)
extern void FaceInfo_set_lineHeight_mDD90F9FD3601ECCC584619250EE463F1587F11AA_AdjustorThunk ();
// 0x00000009 System.Single UnityEngine.TextCore.FaceInfo::get_ascentLine()
extern void FaceInfo_get_ascentLine_m13CEC01C7B73BE33EEFFA354CEF301439CE0E87A_AdjustorThunk ();
// 0x0000000A System.Void UnityEngine.TextCore.FaceInfo::set_ascentLine(System.Single)
extern void FaceInfo_set_ascentLine_m4A223B740073EE53058578E0B243447CC05F06E6_AdjustorThunk ();
// 0x0000000B System.Single UnityEngine.TextCore.FaceInfo::get_capLine()
extern void FaceInfo_get_capLine_m595382AC2AED0EBE2FD0EE34FD62BBD2A2BD0100_AdjustorThunk ();
// 0x0000000C System.Void UnityEngine.TextCore.FaceInfo::set_capLine(System.Single)
extern void FaceInfo_set_capLine_m0E9C415B4B4CF8CAA5DDF415D23D57723A5E4DB3_AdjustorThunk ();
// 0x0000000D System.Void UnityEngine.TextCore.FaceInfo::set_meanLine(System.Single)
extern void FaceInfo_set_meanLine_m9296408D9FB6DC29479C9011118E0C0A07C36EF0_AdjustorThunk ();
// 0x0000000E System.Single UnityEngine.TextCore.FaceInfo::get_baseline()
extern void FaceInfo_get_baseline_m6903D36FD0392A31203A6580D35186DE2DA61CBA_AdjustorThunk ();
// 0x0000000F System.Void UnityEngine.TextCore.FaceInfo::set_baseline(System.Single)
extern void FaceInfo_set_baseline_m413E9CF838D3116208742B77DA439AA19B1153B2_AdjustorThunk ();
// 0x00000010 System.Single UnityEngine.TextCore.FaceInfo::get_descentLine()
extern void FaceInfo_get_descentLine_mCF674AE70BF8C18047BB823008C3A648FAFE750B_AdjustorThunk ();
// 0x00000011 System.Void UnityEngine.TextCore.FaceInfo::set_descentLine(System.Single)
extern void FaceInfo_set_descentLine_mCCECAE131BAEE9D0F6AE5BD788CD15BC25CDBDEE_AdjustorThunk ();
// 0x00000012 System.Single UnityEngine.TextCore.FaceInfo::get_superscriptOffset()
extern void FaceInfo_get_superscriptOffset_m6D6B04E0A73FFDD8EC6D1836DC7E806270F6D947_AdjustorThunk ();
// 0x00000013 System.Void UnityEngine.TextCore.FaceInfo::set_superscriptOffset(System.Single)
extern void FaceInfo_set_superscriptOffset_m028955D8EB3CD9C2BE99165C06B6BE4A769F6C9C_AdjustorThunk ();
// 0x00000014 System.Single UnityEngine.TextCore.FaceInfo::get_superscriptSize()
extern void FaceInfo_get_superscriptSize_m7DAC9FD6EC72892974AA0664A2CD237DCDE99864_AdjustorThunk ();
// 0x00000015 System.Void UnityEngine.TextCore.FaceInfo::set_superscriptSize(System.Single)
extern void FaceInfo_set_superscriptSize_m8CAC9E06CDC52C00323E723CAA1199D238E7142C_AdjustorThunk ();
// 0x00000016 System.Single UnityEngine.TextCore.FaceInfo::get_subscriptOffset()
extern void FaceInfo_get_subscriptOffset_m6FA6DB14BC472CEF9B0056D22192C5F9C161FD91_AdjustorThunk ();
// 0x00000017 System.Void UnityEngine.TextCore.FaceInfo::set_subscriptOffset(System.Single)
extern void FaceInfo_set_subscriptOffset_m069A0EA04A5BD2C227C9635CD7A50FA850BF74A2_AdjustorThunk ();
// 0x00000018 System.Single UnityEngine.TextCore.FaceInfo::get_subscriptSize()
extern void FaceInfo_get_subscriptSize_m44430100DE344AA8BC502C810191A93D2F93FCBD_AdjustorThunk ();
// 0x00000019 System.Void UnityEngine.TextCore.FaceInfo::set_subscriptSize(System.Single)
extern void FaceInfo_set_subscriptSize_m894DD0EFAF75BF99D54FCD344D7B908BC1197F70_AdjustorThunk ();
// 0x0000001A System.Single UnityEngine.TextCore.FaceInfo::get_underlineOffset()
extern void FaceInfo_get_underlineOffset_mF219DC8934F4C0A4EFE10E8856EBABE2FFE8688F_AdjustorThunk ();
// 0x0000001B System.Void UnityEngine.TextCore.FaceInfo::set_underlineOffset(System.Single)
extern void FaceInfo_set_underlineOffset_m199A2AC207C84BC63EBEA6A959329222D441111E_AdjustorThunk ();
// 0x0000001C System.Single UnityEngine.TextCore.FaceInfo::get_underlineThickness()
extern void FaceInfo_get_underlineThickness_mBD8888AA62DCA3EF8390F4958DF4703DA513CD2E_AdjustorThunk ();
// 0x0000001D System.Void UnityEngine.TextCore.FaceInfo::set_underlineThickness(System.Single)
extern void FaceInfo_set_underlineThickness_mA53F991E6ADC225E7CDD319D733FCB88E9B3C2F9_AdjustorThunk ();
// 0x0000001E System.Single UnityEngine.TextCore.FaceInfo::get_strikethroughOffset()
extern void FaceInfo_get_strikethroughOffset_m6D56B3F6B3947CF4C40B351B3E70DE5CCE7B0006_AdjustorThunk ();
// 0x0000001F System.Void UnityEngine.TextCore.FaceInfo::set_strikethroughOffset(System.Single)
extern void FaceInfo_set_strikethroughOffset_m2DE60E5C276D6016FE4CAE20734D43E48A5DEBF1_AdjustorThunk ();
// 0x00000020 System.Void UnityEngine.TextCore.FaceInfo::set_strikethroughThickness(System.Single)
extern void FaceInfo_set_strikethroughThickness_m116BE386CDB6944650E86BD29B1ECC6DB9DEF87A_AdjustorThunk ();
// 0x00000021 System.Single UnityEngine.TextCore.FaceInfo::get_tabWidth()
extern void FaceInfo_get_tabWidth_mEE028F7DF366FABC8F358C064317B2F58BA38C1D_AdjustorThunk ();
// 0x00000022 System.Void UnityEngine.TextCore.FaceInfo::set_tabWidth(System.Single)
extern void FaceInfo_set_tabWidth_mB3A1AF9DB93C0E354608E2AADE9451CF5737B4C5_AdjustorThunk ();
// 0x00000023 System.Int32 UnityEngine.TextCore.GlyphRect::get_x()
extern void GlyphRect_get_x_m0BAD0C0AA39EDD78635C17E6334C06D272C9FEDF_AdjustorThunk ();
// 0x00000024 System.Int32 UnityEngine.TextCore.GlyphRect::get_y()
extern void GlyphRect_get_y_m2149E34A0421CAA14EC681885722D4E587B3103B_AdjustorThunk ();
// 0x00000025 System.Int32 UnityEngine.TextCore.GlyphRect::get_width()
extern void GlyphRect_get_width_mDFB5E23F494329D497B7DE156B831DF6A0D2DC28_AdjustorThunk ();
// 0x00000026 System.Int32 UnityEngine.TextCore.GlyphRect::get_height()
extern void GlyphRect_get_height_mD272F54F14F730E8CAECFE7DC759F9E237374F90_AdjustorThunk ();
// 0x00000027 UnityEngine.TextCore.GlyphRect UnityEngine.TextCore.GlyphRect::get_zero()
extern void GlyphRect_get_zero_mA40D939BFBFB8D3A7301CA4A6D99A1DBDFC34736 ();
// 0x00000028 System.Void UnityEngine.TextCore.GlyphRect::.ctor(System.Int32,System.Int32,System.Int32,System.Int32)
extern void GlyphRect__ctor_mFDDDD22BF8B61E1DE7B24BE8957D918F213AAEC0_AdjustorThunk ();
// 0x00000029 System.Int32 UnityEngine.TextCore.GlyphRect::GetHashCode()
extern void GlyphRect_GetHashCode_m3A99EB971A433E57B195D6C06EBFF5F7ADD4E2E2_AdjustorThunk ();
// 0x0000002A System.Boolean UnityEngine.TextCore.GlyphRect::Equals(System.Object)
extern void GlyphRect_Equals_m0AC7F5A910EDE18B48500657446BD514CA555114_AdjustorThunk ();
// 0x0000002B System.Boolean UnityEngine.TextCore.GlyphRect::Equals(UnityEngine.TextCore.GlyphRect)
extern void GlyphRect_Equals_m1F715BF623E07565AEA7268996F4F57EE3EE9371_AdjustorThunk ();
// 0x0000002C System.Void UnityEngine.TextCore.GlyphRect::.cctor()
extern void GlyphRect__cctor_m5AD2AC6BB42D6536F8F6E2F4369BA400354BFC35 ();
// 0x0000002D System.Single UnityEngine.TextCore.GlyphMetrics::get_width()
extern void GlyphMetrics_get_width_mD69248CE4E78D9D43DFF7573A83637DEE7A47E9E_AdjustorThunk ();
// 0x0000002E System.Single UnityEngine.TextCore.GlyphMetrics::get_height()
extern void GlyphMetrics_get_height_mB5A04A175CFE3D75A523F6287125681C00B9176C_AdjustorThunk ();
// 0x0000002F System.Single UnityEngine.TextCore.GlyphMetrics::get_horizontalBearingX()
extern void GlyphMetrics_get_horizontalBearingX_m8523F1F23BC4A6761FD0378CCED4D5E63843F77E_AdjustorThunk ();
// 0x00000030 System.Single UnityEngine.TextCore.GlyphMetrics::get_horizontalBearingY()
extern void GlyphMetrics_get_horizontalBearingY_mAD3428D1774FA6D75FE8BF77CCB8689F8A76110B_AdjustorThunk ();
// 0x00000031 System.Single UnityEngine.TextCore.GlyphMetrics::get_horizontalAdvance()
extern void GlyphMetrics_get_horizontalAdvance_m1147FB02BC559DB0BF276725DA79F70CACF9FAE0_AdjustorThunk ();
// 0x00000032 System.Void UnityEngine.TextCore.GlyphMetrics::.ctor(System.Single,System.Single,System.Single,System.Single,System.Single)
extern void GlyphMetrics__ctor_m7A9438A14ED6BF7418634DB6FE23052FDB12BE23_AdjustorThunk ();
// 0x00000033 System.Int32 UnityEngine.TextCore.GlyphMetrics::GetHashCode()
extern void GlyphMetrics_GetHashCode_mB88CD082436B6E204011997AB57BFA8843EBBD5C_AdjustorThunk ();
// 0x00000034 System.Boolean UnityEngine.TextCore.GlyphMetrics::Equals(System.Object)
extern void GlyphMetrics_Equals_mF3CC06B964ABE29EF38712324B813677D88856A3_AdjustorThunk ();
// 0x00000035 System.Boolean UnityEngine.TextCore.GlyphMetrics::Equals(UnityEngine.TextCore.GlyphMetrics)
extern void GlyphMetrics_Equals_m9B560B32ACCF0761D3BAD2031882235C7EAD601D_AdjustorThunk ();
// 0x00000036 System.UInt32 UnityEngine.TextCore.Glyph::get_index()
extern void Glyph_get_index_mE8CFBF3B6E08A43EF11AA2E941F7FD9EDFF1C79F ();
// 0x00000037 System.Void UnityEngine.TextCore.Glyph::set_index(System.UInt32)
extern void Glyph_set_index_m188CF50CD0658F2312AF3EA620A7BC8640AAFF1A ();
// 0x00000038 UnityEngine.TextCore.GlyphMetrics UnityEngine.TextCore.Glyph::get_metrics()
extern void Glyph_get_metrics_m25A3C9DDEA15A3EC461A53F194F549699322A811 ();
// 0x00000039 System.Void UnityEngine.TextCore.Glyph::set_metrics(UnityEngine.TextCore.GlyphMetrics)
extern void Glyph_set_metrics_m94E3778C5179B44C6141DFC75202C295ADF00DD9 ();
// 0x0000003A UnityEngine.TextCore.GlyphRect UnityEngine.TextCore.Glyph::get_glyphRect()
extern void Glyph_get_glyphRect_mD937109DC8AE147EED30E0CEB667ACAAE281D4F0 ();
// 0x0000003B System.Void UnityEngine.TextCore.Glyph::set_glyphRect(UnityEngine.TextCore.GlyphRect)
extern void Glyph_set_glyphRect_m5D45BF2EF4A7738AF7158D49DEDB5E09E034742C ();
// 0x0000003C System.Single UnityEngine.TextCore.Glyph::get_scale()
extern void Glyph_get_scale_mB6FDF083196D83B61233ECBF9407A708DE4F692E ();
// 0x0000003D System.Void UnityEngine.TextCore.Glyph::set_scale(System.Single)
extern void Glyph_set_scale_m649B0F686653E1B9F9EA247C8F9F975EADABCF6C ();
// 0x0000003E System.Int32 UnityEngine.TextCore.Glyph::get_atlasIndex()
extern void Glyph_get_atlasIndex_mF246F5C157408FCD5281DBFF08E21CBF28BB529A ();
// 0x0000003F System.Void UnityEngine.TextCore.Glyph::set_atlasIndex(System.Int32)
extern void Glyph_set_atlasIndex_m29899906406A5F1F909359F9F8CB0ED15C64D5E8 ();
// 0x00000040 System.Void UnityEngine.TextCore.Glyph::.ctor()
extern void Glyph__ctor_m21EF1BF22F642135C7C98A7F3E4A025F069A5BA9 ();
// 0x00000041 System.Void UnityEngine.TextCore.Glyph::.ctor(UnityEngine.TextCore.LowLevel.GlyphMarshallingStruct)
extern void Glyph__ctor_mDE5144A797FA0EF0136512443E10B649F3D101BF ();
// 0x00000042 System.Void UnityEngine.TextCore.Glyph::.ctor(System.UInt32,UnityEngine.TextCore.GlyphMetrics,UnityEngine.TextCore.GlyphRect,System.Single,System.Int32)
extern void Glyph__ctor_m138B15C3C7EF727A502378428EE4262C57E7518E ();
// 0x00000043 System.Single UnityEngine.TextCore.LowLevel.GlyphValueRecord::get_xPlacement()
extern void GlyphValueRecord_get_xPlacement_mCC70E3C1C7A2437B47128E74C905B25C452DAF8F_AdjustorThunk ();
// 0x00000044 System.Single UnityEngine.TextCore.LowLevel.GlyphValueRecord::get_yPlacement()
extern void GlyphValueRecord_get_yPlacement_m1785A042219A2303F2AC442CCD12842935474CCD_AdjustorThunk ();
// 0x00000045 System.Single UnityEngine.TextCore.LowLevel.GlyphValueRecord::get_xAdvance()
extern void GlyphValueRecord_get_xAdvance_mF3C5C569D232241F77947296305A8C7C297E8279_AdjustorThunk ();
// 0x00000046 System.Single UnityEngine.TextCore.LowLevel.GlyphValueRecord::get_yAdvance()
extern void GlyphValueRecord_get_yAdvance_mE6A8FDC6406B7A6BFA72852DB976AAFAD0009FE4_AdjustorThunk ();
// 0x00000047 System.UInt32 UnityEngine.TextCore.LowLevel.GlyphAdjustmentRecord::get_glyphIndex()
extern void GlyphAdjustmentRecord_get_glyphIndex_m5E03D5A58AF3664F35E15CC1B449101B96DD0BD3_AdjustorThunk ();
// 0x00000048 UnityEngine.TextCore.LowLevel.GlyphValueRecord UnityEngine.TextCore.LowLevel.GlyphAdjustmentRecord::get_glyphValueRecord()
extern void GlyphAdjustmentRecord_get_glyphValueRecord_m8F2643EF5E5FCD7683AF53BA831603817709E3CC_AdjustorThunk ();
// 0x00000049 UnityEngine.TextCore.LowLevel.GlyphAdjustmentRecord UnityEngine.TextCore.LowLevel.GlyphPairAdjustmentRecord::get_firstAdjustmentRecord()
extern void GlyphPairAdjustmentRecord_get_firstAdjustmentRecord_mDEF2D51630A188E44897AE311E31D2759C4DEF46_AdjustorThunk ();
// 0x0000004A UnityEngine.TextCore.LowLevel.GlyphAdjustmentRecord UnityEngine.TextCore.LowLevel.GlyphPairAdjustmentRecord::get_secondAdjustmentRecord()
extern void GlyphPairAdjustmentRecord_get_secondAdjustmentRecord_m51AFEB36698BA7BD73C96B239F8461374736BB66_AdjustorThunk ();
// 0x0000004B System.Void UnityEngine.TextCore.LowLevel.FontEngine::.ctor()
extern void FontEngine__ctor_m90CBF12264B15BCA2368C372FC2062A06B0E788F ();
// 0x0000004C UnityEngine.TextCore.LowLevel.FontEngineError UnityEngine.TextCore.LowLevel.FontEngine::InitializeFontEngine()
extern void FontEngine_InitializeFontEngine_m1C7695D66160277DE576EB9D8BA749849BDC24B7 ();
// 0x0000004D System.Int32 UnityEngine.TextCore.LowLevel.FontEngine::InitializeFontEngine_Internal()
extern void FontEngine_InitializeFontEngine_Internal_m1E2A10F8DAB78AD620024ECFA665C55F91B55445 ();
// 0x0000004E UnityEngine.TextCore.LowLevel.FontEngineError UnityEngine.TextCore.LowLevel.FontEngine::LoadFontFace(UnityEngine.Font,System.Int32)
extern void FontEngine_LoadFontFace_mFEBC3184605C0BD37A83021F6B47E5C3FA3FAD3C ();
// 0x0000004F System.Int32 UnityEngine.TextCore.LowLevel.FontEngine::LoadFontFace_With_Size_FromFont_Internal(UnityEngine.Font,System.Int32)
extern void FontEngine_LoadFontFace_With_Size_FromFont_Internal_m325AFCA4FC2C627409FC9831A009940112D6B013 ();
// 0x00000050 UnityEngine.TextCore.FaceInfo UnityEngine.TextCore.LowLevel.FontEngine::GetFaceInfo()
extern void FontEngine_GetFaceInfo_mB4B6045A34FEBFE58EB401216E930F50364B0A41 ();
// 0x00000051 System.Int32 UnityEngine.TextCore.LowLevel.FontEngine::GetFaceInfo_Internal(UnityEngine.TextCore.FaceInfo&)
extern void FontEngine_GetFaceInfo_Internal_m651FC0E71B8D4FB858C70374126E142659537F8C ();
// 0x00000052 System.UInt32 UnityEngine.TextCore.LowLevel.FontEngine::GetGlyphIndex(System.UInt32)
extern void FontEngine_GetGlyphIndex_m9877A2238C4292F3CC5F72688E4BB2EBBB9DBCB1 ();
// 0x00000053 System.Boolean UnityEngine.TextCore.LowLevel.FontEngine::TryGetGlyphWithUnicodeValue(System.UInt32,UnityEngine.TextCore.LowLevel.GlyphLoadFlags,UnityEngine.TextCore.Glyph&)
extern void FontEngine_TryGetGlyphWithUnicodeValue_mBC940303E740DC1897FCA6247D048266298BE00C ();
// 0x00000054 System.Boolean UnityEngine.TextCore.LowLevel.FontEngine::TryGetGlyphWithUnicodeValue_Internal(System.UInt32,UnityEngine.TextCore.LowLevel.GlyphLoadFlags,UnityEngine.TextCore.LowLevel.GlyphMarshallingStruct&)
extern void FontEngine_TryGetGlyphWithUnicodeValue_Internal_m8B4C9643A51BB4D3E1F83C7DDF593E9247D5A38C ();
// 0x00000055 System.Boolean UnityEngine.TextCore.LowLevel.FontEngine::TryGetGlyphWithIndexValue(System.UInt32,UnityEngine.TextCore.LowLevel.GlyphLoadFlags,UnityEngine.TextCore.Glyph&)
extern void FontEngine_TryGetGlyphWithIndexValue_m75A9F7605232FAF4D9948E2E7BDFFB01A8FD5178 ();
// 0x00000056 System.Boolean UnityEngine.TextCore.LowLevel.FontEngine::TryGetGlyphWithIndexValue_Internal(System.UInt32,UnityEngine.TextCore.LowLevel.GlyphLoadFlags,UnityEngine.TextCore.LowLevel.GlyphMarshallingStruct&)
extern void FontEngine_TryGetGlyphWithIndexValue_Internal_mB4D0E3754E546E77B9F0D6C1A0A621C273B0D170 ();
// 0x00000057 System.Boolean UnityEngine.TextCore.LowLevel.FontEngine::TryPackGlyphInAtlas(UnityEngine.TextCore.Glyph,System.Int32,UnityEngine.TextCore.LowLevel.GlyphPackingMode,UnityEngine.TextCore.LowLevel.GlyphRenderMode,System.Int32,System.Int32,System.Collections.Generic.List`1<UnityEngine.TextCore.GlyphRect>,System.Collections.Generic.List`1<UnityEngine.TextCore.GlyphRect>)
extern void FontEngine_TryPackGlyphInAtlas_m0E9E8FBBC64AF69CB1DEB3C8A2EF862222C3B8EA ();
// 0x00000058 System.Boolean UnityEngine.TextCore.LowLevel.FontEngine::TryPackGlyphInAtlas_Internal(UnityEngine.TextCore.LowLevel.GlyphMarshallingStruct&,System.Int32,UnityEngine.TextCore.LowLevel.GlyphPackingMode,UnityEngine.TextCore.LowLevel.GlyphRenderMode,System.Int32,System.Int32,UnityEngine.TextCore.GlyphRect[],System.Int32&,UnityEngine.TextCore.GlyphRect[],System.Int32&)
extern void FontEngine_TryPackGlyphInAtlas_Internal_m5FFA31006069F5F44A10B55C2BE8BF7C6BB91A9B ();
// 0x00000059 UnityEngine.TextCore.LowLevel.FontEngineError UnityEngine.TextCore.LowLevel.FontEngine::RenderGlyphsToTexture(System.Collections.Generic.List`1<UnityEngine.TextCore.Glyph>,System.Int32,UnityEngine.TextCore.LowLevel.GlyphRenderMode,UnityEngine.Texture2D)
extern void FontEngine_RenderGlyphsToTexture_m6A61FED7FC28A80B730C4B2C492A8E802DD2EB80 ();
// 0x0000005A System.Int32 UnityEngine.TextCore.LowLevel.FontEngine::RenderGlyphsToTexture_Internal(UnityEngine.TextCore.LowLevel.GlyphMarshallingStruct[],System.Int32,System.Int32,UnityEngine.TextCore.LowLevel.GlyphRenderMode,UnityEngine.Texture2D)
extern void FontEngine_RenderGlyphsToTexture_Internal_m75E35FA3BB446FAD0E9574A2109BF1AF8758218D ();
// 0x0000005B System.Boolean UnityEngine.TextCore.LowLevel.FontEngine::TryAddGlyphToTexture(System.UInt32,System.Int32,UnityEngine.TextCore.LowLevel.GlyphPackingMode,System.Collections.Generic.List`1<UnityEngine.TextCore.GlyphRect>,System.Collections.Generic.List`1<UnityEngine.TextCore.GlyphRect>,UnityEngine.TextCore.LowLevel.GlyphRenderMode,UnityEngine.Texture2D,UnityEngine.TextCore.Glyph&)
extern void FontEngine_TryAddGlyphToTexture_mD70AEC0FDCEE818B4366C78FF662464F13112172 ();
// 0x0000005C System.Boolean UnityEngine.TextCore.LowLevel.FontEngine::TryAddGlyphToTexture_Internal(System.UInt32,System.Int32,UnityEngine.TextCore.LowLevel.GlyphPackingMode,UnityEngine.TextCore.GlyphRect[],System.Int32&,UnityEngine.TextCore.GlyphRect[],System.Int32&,UnityEngine.TextCore.LowLevel.GlyphRenderMode,UnityEngine.Texture2D,UnityEngine.TextCore.LowLevel.GlyphMarshallingStruct&)
extern void FontEngine_TryAddGlyphToTexture_Internal_mAD9085B9AF5B6BEBAB100A0F0DD3114CF23B7E82 ();
// 0x0000005D System.Boolean UnityEngine.TextCore.LowLevel.FontEngine::TryAddGlyphsToTexture(System.Collections.Generic.List`1<System.UInt32>,System.Int32,UnityEngine.TextCore.LowLevel.GlyphPackingMode,System.Collections.Generic.List`1<UnityEngine.TextCore.GlyphRect>,System.Collections.Generic.List`1<UnityEngine.TextCore.GlyphRect>,UnityEngine.TextCore.LowLevel.GlyphRenderMode,UnityEngine.Texture2D,UnityEngine.TextCore.Glyph[]&)
extern void FontEngine_TryAddGlyphsToTexture_mFC834881F6DB0867C01A9902A879C13ED66404A4 ();
// 0x0000005E System.Boolean UnityEngine.TextCore.LowLevel.FontEngine::TryAddGlyphsToTexture_Internal(System.UInt32[],System.Int32,UnityEngine.TextCore.LowLevel.GlyphPackingMode,UnityEngine.TextCore.GlyphRect[],System.Int32&,UnityEngine.TextCore.GlyphRect[],System.Int32&,UnityEngine.TextCore.LowLevel.GlyphRenderMode,UnityEngine.Texture2D,UnityEngine.TextCore.LowLevel.GlyphMarshallingStruct[],System.Int32&)
extern void FontEngine_TryAddGlyphsToTexture_Internal_m8A1C14812C18BE60C2C3795D1DD21FFE6B9C3EEB ();
// 0x0000005F UnityEngine.TextCore.LowLevel.GlyphPairAdjustmentRecord[] UnityEngine.TextCore.LowLevel.FontEngine::GetGlyphPairAdjustmentTable(System.UInt32[])
extern void FontEngine_GetGlyphPairAdjustmentTable_m1FC9B74860076DCCECBCE77EEA38737FB32DF24B ();
// 0x00000060 System.Int32 UnityEngine.TextCore.LowLevel.FontEngine::GetGlyphPairAdjustmentTable_Internal(System.UInt32[],UnityEngine.TextCore.LowLevel.GlyphPairAdjustmentRecord[],System.Int32&)
extern void FontEngine_GetGlyphPairAdjustmentTable_Internal_m8A6247127839E83B66B84C0898E64ADA151996D8 ();
// 0x00000061 System.Void UnityEngine.TextCore.LowLevel.FontEngine::ResetAtlasTexture(UnityEngine.Texture2D)
extern void FontEngine_ResetAtlasTexture_mAC70CAE4652D8D5F7F2A623DB2CA5F7DB6C5293E ();
// 0x00000062 System.Void UnityEngine.TextCore.LowLevel.FontEngine::.cctor()
extern void FontEngine__cctor_m17164EA5533727BA15D0E56719925E8AA986F7BC ();
// 0x00000063 System.Int32 UnityEngine.TextCore.LowLevel.FontEngineUtilities::MaxValue(System.Int32,System.Int32,System.Int32)
extern void FontEngineUtilities_MaxValue_mFF6CBAAE6C3015C2A0E7492A381F6F2118CA1215 ();
// 0x00000064 System.Void UnityEngine.TextCore.LowLevel.GlyphMarshallingStruct::.ctor(UnityEngine.TextCore.Glyph)
extern void GlyphMarshallingStruct__ctor_mC65A885AB9C9D04B45FB90DF913C6404DA655220_AdjustorThunk ();
static Il2CppMethodPointer s_methodPointers[100] = 
{
	FaceInfo_set_familyName_m070B9D53BD86AF04CD44A193236472B863B2A5AD_AdjustorThunk,
	FaceInfo_set_styleName_m178E36C8E91C5F733CC14C8F1C72D9261DF75689_AdjustorThunk,
	FaceInfo_get_pointSize_m7FF87189B44B164920FDFBC1AF255255F310B5FF_AdjustorThunk,
	FaceInfo_set_pointSize_m78055606128C35E03B858125ACE7D433EB282949_AdjustorThunk,
	FaceInfo_get_scale_mF90743435232CC99211482A602E0E8FC85F177F0_AdjustorThunk,
	FaceInfo_set_scale_m785FEBD05216CE8D6A125CFBEFE0D107ACFA7267_AdjustorThunk,
	FaceInfo_get_lineHeight_m524B1B20AEED2B8A3E9BEA9E2CD1ECBCF0C39E61_AdjustorThunk,
	FaceInfo_set_lineHeight_mDD90F9FD3601ECCC584619250EE463F1587F11AA_AdjustorThunk,
	FaceInfo_get_ascentLine_m13CEC01C7B73BE33EEFFA354CEF301439CE0E87A_AdjustorThunk,
	FaceInfo_set_ascentLine_m4A223B740073EE53058578E0B243447CC05F06E6_AdjustorThunk,
	FaceInfo_get_capLine_m595382AC2AED0EBE2FD0EE34FD62BBD2A2BD0100_AdjustorThunk,
	FaceInfo_set_capLine_m0E9C415B4B4CF8CAA5DDF415D23D57723A5E4DB3_AdjustorThunk,
	FaceInfo_set_meanLine_m9296408D9FB6DC29479C9011118E0C0A07C36EF0_AdjustorThunk,
	FaceInfo_get_baseline_m6903D36FD0392A31203A6580D35186DE2DA61CBA_AdjustorThunk,
	FaceInfo_set_baseline_m413E9CF838D3116208742B77DA439AA19B1153B2_AdjustorThunk,
	FaceInfo_get_descentLine_mCF674AE70BF8C18047BB823008C3A648FAFE750B_AdjustorThunk,
	FaceInfo_set_descentLine_mCCECAE131BAEE9D0F6AE5BD788CD15BC25CDBDEE_AdjustorThunk,
	FaceInfo_get_superscriptOffset_m6D6B04E0A73FFDD8EC6D1836DC7E806270F6D947_AdjustorThunk,
	FaceInfo_set_superscriptOffset_m028955D8EB3CD9C2BE99165C06B6BE4A769F6C9C_AdjustorThunk,
	FaceInfo_get_superscriptSize_m7DAC9FD6EC72892974AA0664A2CD237DCDE99864_AdjustorThunk,
	FaceInfo_set_superscriptSize_m8CAC9E06CDC52C00323E723CAA1199D238E7142C_AdjustorThunk,
	FaceInfo_get_subscriptOffset_m6FA6DB14BC472CEF9B0056D22192C5F9C161FD91_AdjustorThunk,
	FaceInfo_set_subscriptOffset_m069A0EA04A5BD2C227C9635CD7A50FA850BF74A2_AdjustorThunk,
	FaceInfo_get_subscriptSize_m44430100DE344AA8BC502C810191A93D2F93FCBD_AdjustorThunk,
	FaceInfo_set_subscriptSize_m894DD0EFAF75BF99D54FCD344D7B908BC1197F70_AdjustorThunk,
	FaceInfo_get_underlineOffset_mF219DC8934F4C0A4EFE10E8856EBABE2FFE8688F_AdjustorThunk,
	FaceInfo_set_underlineOffset_m199A2AC207C84BC63EBEA6A959329222D441111E_AdjustorThunk,
	FaceInfo_get_underlineThickness_mBD8888AA62DCA3EF8390F4958DF4703DA513CD2E_AdjustorThunk,
	FaceInfo_set_underlineThickness_mA53F991E6ADC225E7CDD319D733FCB88E9B3C2F9_AdjustorThunk,
	FaceInfo_get_strikethroughOffset_m6D56B3F6B3947CF4C40B351B3E70DE5CCE7B0006_AdjustorThunk,
	FaceInfo_set_strikethroughOffset_m2DE60E5C276D6016FE4CAE20734D43E48A5DEBF1_AdjustorThunk,
	FaceInfo_set_strikethroughThickness_m116BE386CDB6944650E86BD29B1ECC6DB9DEF87A_AdjustorThunk,
	FaceInfo_get_tabWidth_mEE028F7DF366FABC8F358C064317B2F58BA38C1D_AdjustorThunk,
	FaceInfo_set_tabWidth_mB3A1AF9DB93C0E354608E2AADE9451CF5737B4C5_AdjustorThunk,
	GlyphRect_get_x_m0BAD0C0AA39EDD78635C17E6334C06D272C9FEDF_AdjustorThunk,
	GlyphRect_get_y_m2149E34A0421CAA14EC681885722D4E587B3103B_AdjustorThunk,
	GlyphRect_get_width_mDFB5E23F494329D497B7DE156B831DF6A0D2DC28_AdjustorThunk,
	GlyphRect_get_height_mD272F54F14F730E8CAECFE7DC759F9E237374F90_AdjustorThunk,
	GlyphRect_get_zero_mA40D939BFBFB8D3A7301CA4A6D99A1DBDFC34736,
	GlyphRect__ctor_mFDDDD22BF8B61E1DE7B24BE8957D918F213AAEC0_AdjustorThunk,
	GlyphRect_GetHashCode_m3A99EB971A433E57B195D6C06EBFF5F7ADD4E2E2_AdjustorThunk,
	GlyphRect_Equals_m0AC7F5A910EDE18B48500657446BD514CA555114_AdjustorThunk,
	GlyphRect_Equals_m1F715BF623E07565AEA7268996F4F57EE3EE9371_AdjustorThunk,
	GlyphRect__cctor_m5AD2AC6BB42D6536F8F6E2F4369BA400354BFC35,
	GlyphMetrics_get_width_mD69248CE4E78D9D43DFF7573A83637DEE7A47E9E_AdjustorThunk,
	GlyphMetrics_get_height_mB5A04A175CFE3D75A523F6287125681C00B9176C_AdjustorThunk,
	GlyphMetrics_get_horizontalBearingX_m8523F1F23BC4A6761FD0378CCED4D5E63843F77E_AdjustorThunk,
	GlyphMetrics_get_horizontalBearingY_mAD3428D1774FA6D75FE8BF77CCB8689F8A76110B_AdjustorThunk,
	GlyphMetrics_get_horizontalAdvance_m1147FB02BC559DB0BF276725DA79F70CACF9FAE0_AdjustorThunk,
	GlyphMetrics__ctor_m7A9438A14ED6BF7418634DB6FE23052FDB12BE23_AdjustorThunk,
	GlyphMetrics_GetHashCode_mB88CD082436B6E204011997AB57BFA8843EBBD5C_AdjustorThunk,
	GlyphMetrics_Equals_mF3CC06B964ABE29EF38712324B813677D88856A3_AdjustorThunk,
	GlyphMetrics_Equals_m9B560B32ACCF0761D3BAD2031882235C7EAD601D_AdjustorThunk,
	Glyph_get_index_mE8CFBF3B6E08A43EF11AA2E941F7FD9EDFF1C79F,
	Glyph_set_index_m188CF50CD0658F2312AF3EA620A7BC8640AAFF1A,
	Glyph_get_metrics_m25A3C9DDEA15A3EC461A53F194F549699322A811,
	Glyph_set_metrics_m94E3778C5179B44C6141DFC75202C295ADF00DD9,
	Glyph_get_glyphRect_mD937109DC8AE147EED30E0CEB667ACAAE281D4F0,
	Glyph_set_glyphRect_m5D45BF2EF4A7738AF7158D49DEDB5E09E034742C,
	Glyph_get_scale_mB6FDF083196D83B61233ECBF9407A708DE4F692E,
	Glyph_set_scale_m649B0F686653E1B9F9EA247C8F9F975EADABCF6C,
	Glyph_get_atlasIndex_mF246F5C157408FCD5281DBFF08E21CBF28BB529A,
	Glyph_set_atlasIndex_m29899906406A5F1F909359F9F8CB0ED15C64D5E8,
	Glyph__ctor_m21EF1BF22F642135C7C98A7F3E4A025F069A5BA9,
	Glyph__ctor_mDE5144A797FA0EF0136512443E10B649F3D101BF,
	Glyph__ctor_m138B15C3C7EF727A502378428EE4262C57E7518E,
	GlyphValueRecord_get_xPlacement_mCC70E3C1C7A2437B47128E74C905B25C452DAF8F_AdjustorThunk,
	GlyphValueRecord_get_yPlacement_m1785A042219A2303F2AC442CCD12842935474CCD_AdjustorThunk,
	GlyphValueRecord_get_xAdvance_mF3C5C569D232241F77947296305A8C7C297E8279_AdjustorThunk,
	GlyphValueRecord_get_yAdvance_mE6A8FDC6406B7A6BFA72852DB976AAFAD0009FE4_AdjustorThunk,
	GlyphAdjustmentRecord_get_glyphIndex_m5E03D5A58AF3664F35E15CC1B449101B96DD0BD3_AdjustorThunk,
	GlyphAdjustmentRecord_get_glyphValueRecord_m8F2643EF5E5FCD7683AF53BA831603817709E3CC_AdjustorThunk,
	GlyphPairAdjustmentRecord_get_firstAdjustmentRecord_mDEF2D51630A188E44897AE311E31D2759C4DEF46_AdjustorThunk,
	GlyphPairAdjustmentRecord_get_secondAdjustmentRecord_m51AFEB36698BA7BD73C96B239F8461374736BB66_AdjustorThunk,
	FontEngine__ctor_m90CBF12264B15BCA2368C372FC2062A06B0E788F,
	FontEngine_InitializeFontEngine_m1C7695D66160277DE576EB9D8BA749849BDC24B7,
	FontEngine_InitializeFontEngine_Internal_m1E2A10F8DAB78AD620024ECFA665C55F91B55445,
	FontEngine_LoadFontFace_mFEBC3184605C0BD37A83021F6B47E5C3FA3FAD3C,
	FontEngine_LoadFontFace_With_Size_FromFont_Internal_m325AFCA4FC2C627409FC9831A009940112D6B013,
	FontEngine_GetFaceInfo_mB4B6045A34FEBFE58EB401216E930F50364B0A41,
	FontEngine_GetFaceInfo_Internal_m651FC0E71B8D4FB858C70374126E142659537F8C,
	FontEngine_GetGlyphIndex_m9877A2238C4292F3CC5F72688E4BB2EBBB9DBCB1,
	FontEngine_TryGetGlyphWithUnicodeValue_mBC940303E740DC1897FCA6247D048266298BE00C,
	FontEngine_TryGetGlyphWithUnicodeValue_Internal_m8B4C9643A51BB4D3E1F83C7DDF593E9247D5A38C,
	FontEngine_TryGetGlyphWithIndexValue_m75A9F7605232FAF4D9948E2E7BDFFB01A8FD5178,
	FontEngine_TryGetGlyphWithIndexValue_Internal_mB4D0E3754E546E77B9F0D6C1A0A621C273B0D170,
	FontEngine_TryPackGlyphInAtlas_m0E9E8FBBC64AF69CB1DEB3C8A2EF862222C3B8EA,
	FontEngine_TryPackGlyphInAtlas_Internal_m5FFA31006069F5F44A10B55C2BE8BF7C6BB91A9B,
	FontEngine_RenderGlyphsToTexture_m6A61FED7FC28A80B730C4B2C492A8E802DD2EB80,
	FontEngine_RenderGlyphsToTexture_Internal_m75E35FA3BB446FAD0E9574A2109BF1AF8758218D,
	FontEngine_TryAddGlyphToTexture_mD70AEC0FDCEE818B4366C78FF662464F13112172,
	FontEngine_TryAddGlyphToTexture_Internal_mAD9085B9AF5B6BEBAB100A0F0DD3114CF23B7E82,
	FontEngine_TryAddGlyphsToTexture_mFC834881F6DB0867C01A9902A879C13ED66404A4,
	FontEngine_TryAddGlyphsToTexture_Internal_m8A1C14812C18BE60C2C3795D1DD21FFE6B9C3EEB,
	FontEngine_GetGlyphPairAdjustmentTable_m1FC9B74860076DCCECBCE77EEA38737FB32DF24B,
	FontEngine_GetGlyphPairAdjustmentTable_Internal_m8A6247127839E83B66B84C0898E64ADA151996D8,
	FontEngine_ResetAtlasTexture_mAC70CAE4652D8D5F7F2A623DB2CA5F7DB6C5293E,
	FontEngine__cctor_m17164EA5533727BA15D0E56719925E8AA986F7BC,
	FontEngineUtilities_MaxValue_mFF6CBAAE6C3015C2A0E7492A381F6F2118CA1215,
	GlyphMarshallingStruct__ctor_mC65A885AB9C9D04B45FB90DF913C6404DA655220_AdjustorThunk,
};
static const int32_t s_InvokerIndices[100] = 
{
	26,
	26,
	10,
	32,
	679,
	290,
	679,
	290,
	679,
	290,
	679,
	290,
	290,
	679,
	290,
	679,
	290,
	679,
	290,
	679,
	290,
	679,
	290,
	679,
	290,
	679,
	290,
	679,
	290,
	679,
	290,
	290,
	679,
	290,
	10,
	10,
	10,
	10,
	1464,
	294,
	10,
	9,
	1465,
	3,
	679,
	679,
	679,
	679,
	679,
	1466,
	10,
	9,
	1467,
	10,
	32,
	1468,
	1469,
	1470,
	1471,
	679,
	290,
	10,
	32,
	23,
	1472,
	1473,
	679,
	679,
	679,
	679,
	10,
	1474,
	1475,
	1475,
	23,
	131,
	131,
	182,
	182,
	1476,
	444,
	21,
	1477,
	1477,
	1477,
	1477,
	1478,
	1479,
	147,
	1480,
	1481,
	1482,
	1483,
	1484,
	0,
	1485,
	122,
	3,
	170,
	26,
};
extern const Il2CppCodeGenModule g_UnityEngine_TextCoreModuleCodeGenModule;
const Il2CppCodeGenModule g_UnityEngine_TextCoreModuleCodeGenModule = 
{
	"UnityEngine.TextCoreModule.dll",
	100,
	s_methodPointers,
	s_InvokerIndices,
	0,
	NULL,
	0,
	NULL,
	0,
	NULL,
	NULL,
};
